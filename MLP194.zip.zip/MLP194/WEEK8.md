# Week #8: Course Materials
    * Angular
    
The objective of week #8 is to get the employee details to the web ui in the list. Also to add change to the unit and system tests.

## Angular 6/7

## Karma/Jasmine

## Protractor

# Week #8

    * Sprint goals
       * Trello Project Board Task: To start on the web interface and complete the basic screens 
      
# Reading material

## Must-Read

### Angular
  * Typescript
    * Promises: https://basarat.gitbooks.io/typescript/docs/promise.html
  * Angular Intro
    * https://www.youtube.com/watch?v=KhzGSHNhnbI

## Nice-To-Read

## Go-Deep

  

  
