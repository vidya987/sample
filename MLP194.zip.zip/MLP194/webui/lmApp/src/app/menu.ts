export class Menu {
    constructor(public foodId: string,
        public foodName: string,
        public vendor: string){
            
        }
}