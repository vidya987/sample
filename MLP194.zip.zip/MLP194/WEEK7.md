# Week #7: Course Materials
       * Rest Assured
       * Angular 6/7

The objective of week #7 is to complete the testing for Restful webservice using Rest Assured
    
# Reading material

## Must-Read

## Nice-To-Read

## Go-Deep

  
