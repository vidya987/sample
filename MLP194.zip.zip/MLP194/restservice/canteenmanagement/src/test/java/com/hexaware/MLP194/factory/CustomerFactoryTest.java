package com.hexaware.MLP194.factory;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import java.util.ArrayList;
import com.hexaware.MLP194.model.Customer;
import com.hexaware.MLP194.persistence.CustomerDAO;
import org.junit.Test;
import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;

//This class test Factory class of Car
/**
 * to get details of Customer.
 */
public class CustomerFactoryTest {
 /**
  * @param dao to get dao details.
 */
  @Test
  public final void testGetAllCustomer(@Mocked final CustomerDAO dao) {
    final Customer karapakkam = new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000);
    final ArrayList<Customer> carList = new ArrayList<Customer>();
    new Expectations() {
      {
        carList.add(karapakkam);
        dao.show();
        result = carList;
      }
    };

    new MockUp<CustomerFactory>() {
      @Mock
      CustomerDAO dao() {
        return dao;
      }
    };

    Customer[] customerList1 = CustomerFactory.showCustomer();
    assertEquals(karapakkam, customerList1[0]);

  }
  /**
   * @param dao to get dao details.
   */
  @Test
  public final void testInsertAllCustomer(@Mocked final CustomerDAO dao) {
    //Customer newCustomer = new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000);
    //final Customer karapakkam = new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2");
    final int i = dao.insert(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000);
    new Expectations() {
      {
        System.out.println("mocked get Customer login");
        dao.insert(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000);
        result = 0;
      }
    };

    new MockUp<CustomerFactory>() {

      @Mock
      CustomerDAO dao() {
        return dao;
      }
    };

    int  customerList2 = CustomerFactory.insertingCustomer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000);
    assertEquals(i, customerList2);

  }
  /**
   * @param dao to get dao details.
   */
  @Test
  public final void updatingCustomers(@Mocked final CustomerDAO dao) {
    //Customer newCustomer = new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000);
    final int i = dao.update(9600340997L, "karapakkam", 1);
    new Expectations() {
      {
        dao.update(9600340997L, "karapakkam", 1);
        result = i;
      }
    };
    new MockUp<CustomerFactory>() {
      @Mock
      CustomerDAO dao() {
        System.out.println("Mocked Student Dao");
        return dao;
      }
    };
    final int w3 = CustomerFactory.updatingCustomer(9600340997L, "karapakkam", 1);
    assertEquals(i, w3);
  }
  /**
   * @param dao to test balance amount.
   */
  @Test
  public final void  validatingCustomer1(@Mocked final CustomerDAO dao) {
    final Customer i = dao.validating(1, "thankgod2");
    new Expectations() {
      {
        dao.validating(1, "thankgod2");
        result = i;
      }
    };
    new MockUp<CustomerFactory>() {
      @Mock
      CustomerDAO dao() {
        System.out.println("Mocked Customer Dao");
        return dao;
      }
    };
    Customer w5 = CustomerFactory.validatingCustomer(1, "thankgod2");
    assertEquals(i, w5);
  }
  /**
   * @param dao to test deleting wallet.
   */
  @Test
  public final void customerCoupon1(@Mocked final CustomerDAO dao) {
    final Customer i = dao.customerCoupon(1);
    new Expectations() {
      {
        dao.customerCoupon(1);
        result = i;
      }
    };
    new MockUp<CustomerFactory>() {
      @Mock
      CustomerDAO dao() {
        System.out.println("Mocked Customer Dao");
        return dao;
      }
    };
    Customer w6 = CustomerFactory.validatingCustomerCoupon(1);
    assertEquals(i, w6);
  }
    /**
   * @param dao to test detecting balance.
   */
  @Test
  public final void customerCouponOffers(@Mocked final CustomerDAO dao) {
    final int i = dao.updateWallet(15000, 1);
    new Expectations() {
      {
        dao.updateWallet(15000, 1);
        result = i;
      }
    };
    new MockUp<CustomerFactory>() {
      @Mock
      CustomerDAO dao() {
        System.out.println("Mocked Customer Dao");
        return dao;
      }
    };
    int w7 = CustomerFactory.deductAmount(15000, 1);
    assertEquals(i, w7);
  }
  /**
  * default constructor testing.
 */
  @Test
public final void testDefaultConstructor() {
    CustomerFactory mf = new CustomerFactory();
    CustomerFactory mf1 = new CustomerFactory();
    assertNotEquals(mf.hashCode(), mf1.hashCode());
  }
/**
 * constructor testing.
 */
  @Test
  public final void testParameterisedCustomer() {
    Customer customer = new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000);
    assertEquals(1, customer.getCusId());
    assertEquals(1221, customer.getWalNo());
    assertEquals(9600340997L, customer.getPhnNo());
    assertEquals("karapakkam", customer.getAddRess());
    assertEquals(103, customer.getCrdNo());
    assertEquals("thankgod2", customer.getPswd());
    assertEquals(15000, customer.getbalance());
  }
  /**
   * To test getters and setters.
   */
  @Test
  public final void testCustomerSetPoint() {
    Customer newcustomer = new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000);
    newcustomer.setCusId(10);
    assertEquals(10, newcustomer.getCusId());
  }
}

