package com.hexaware.MLP194.factory;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import java.util.ArrayList;
import com.hexaware.MLP194.model.Wallet;
import com.hexaware.MLP194.persistence.WalletDAO;
import org.junit.Test;
import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;

//This class test Factory class of Wallet.
/**
 * to get details of wallet.
 */
public class WalletFactoryTest {
 /**
 * @param dao to get dao details.
 */

  @Test
  public final void testGetAllWallet(@Mocked final WalletDAO dao) {
    final Wallet w = new Wallet(6, 1221, 1, 500);
    final ArrayList<Wallet> walletList = new ArrayList<Wallet>();
    new Expectations() {
      {
        walletList.add(0, w);
        dao.show();
        result = walletList;
      }
    };
    new MockUp<WalletFactory>() {
      @Mock
      WalletDAO dao() {
          return dao;
      }
    };

    Wallet[] walletList1 = WalletFactory.showMenu();
    assertNotEquals(0, walletList1[0]);
  }
 /**
   * @param dao test inserting wallet
   */
  @Test
  public final void insertingWallet(@Mocked final WalletDAO dao) {
    final int i = dao.insertWallet(6, 1221, 1, 500);
    new Expectations() {
      {
        dao.insertWallet(6, 1221, 1, 500);
        result = i;
      }
    };
    new MockUp<WalletFactory>() {
      @Mock
      WalletDAO dao() {
        System.out.println("Mocked Student Dao");
        return dao;
      }
    };
    int w2 = WalletFactory.insertingWallet(6, 1221, 1, 500);
    assertEquals(i, w2);
  }
  /**
   * @param dao to test updating wallet.
   */
  @Test
  public final void updatingWallet(@Mocked final WalletDAO dao) {
    final int i = dao.updateWallet(1222, 7);
    new Expectations() {
      {
        dao.updateWallet(1222, 7);
        result = i;
      }
    };
    new MockUp<WalletFactory>() {
      @Mock
      WalletDAO dao() {
        System.out.println("Mocked Student Dao");
        return dao;
      }
    };
    int w3 = WalletFactory.updatingWallet(1222, 7);
    assertEquals(i, w3);
  }
  /**
   * @param dao to test balance amount.
   */
  @Test
  public final void balancingAmount(@Mocked final WalletDAO dao) {
    final int i = dao.balanceAmount(500, 1);
    new Expectations() {
      {
        dao.balanceAmount(500, 1);
        result = i;
      }
    };
    new MockUp<WalletFactory>() {
      @Mock
      WalletDAO dao() {
        System.out.println("Mocked Student Dao");
        return dao;
      }
    };
    int w5 = WalletFactory.balancingAmount(500, 1);
    assertEquals(i, w5);
  }
 /**
  * default constructor testing.
 */
  @Test
public final void testDefaultConstructor() {
    WalletFactory mf = new WalletFactory();
    WalletFactory mf1 = new WalletFactory();
    assertNotEquals(mf.hashCode(), mf1.hashCode());
  }
  /**
   * constructor testing.
   */
  @Test
  public final void testWalletParameterised() {
    Wallet newwallet = new Wallet(6, 7, 1, 5000);
    assertEquals(6, newwallet.getwltPt());
    assertEquals(7, newwallet.getwltNo());
    assertEquals(1, newwallet.getCusId());
    assertEquals(5000, newwallet.getbalance());
  }
  /**
   * To test getters and setters.
   */
  @Test
  public final void testWalletSetPoint() {
    Wallet newwallet1 = new Wallet(6, 7, 1, 5000);
    newwallet1.setwltPt(10);
    assertEquals(10, newwallet1.getwltPt());
  }
}
