package com.hexaware.MLP194.factory;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import com.hexaware.MLP194.model.Coupon;
import com.hexaware.MLP194.persistence.CouponDAO;
import org.junit.Test;
import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;

/**
 * initializing customer factory.
 */
public class CouponFactoryTest {
  private LocalDate d1, d2;

  /**
   * tests that order is handled correctly.
   *
   * @param dao mocking the dao class
   * @throws ParseException exception
   */
  @Test

  public final void addCoupon(@Mocked final CouponDAO dao) throws ParseException {
    //final DateTimeFormatter sdf;
    String date1 = "2020-02-10";
    String date2 = "2020-02-22";
    DateTimeFormatter.ofPattern("yyyy-MM-dd");
    //sdf.setLenient(false);
    d1 = LocalDate.parse(date1);
    d2 = LocalDate.parse(date2);
    final Coupon c1 = new Coupon();
    new Expectations() {
      {
        System.out.println("mocked get offers");
        CouponFactory.addCoupon("free10", d1, d2, 1);
        result = c1;
      }
    };
    new MockUp<CouponFactory>() {
      @Mock
      CouponDAO dao() {
        System.out.println("Mocked Offers Dao");
        return dao;
      }
    };
    int offers = CouponFactory.addCoupon("free10", d1, d2, 1);
    assertNotEquals(c1, offers);
  }

  /**
   * tests that order is handled correctly.
   * @param dao mocking the dao class
   */
  @Test

  public final void checkcoupcus(@Mocked final CouponDAO dao) {
    final Coupon c3 = new Coupon();
    new Expectations() {
      {
        System.out.println("mocked get Offers");
        CouponFactory.checkcoupcus(1);
        result = c3;
      }
    };
    new MockUp<CouponFactory>() {
      @Mock
      CouponDAO dao() {
        System.out.println("Mocked Offers Dao");
        return dao;
      }
    };
    int offers = CouponFactory.checkcoupcus(1);
    assertNotEquals(c3, offers);
  }
/**
 * @param dao g
 */
  @Test
  public final void endcoupondate(@Mocked final CouponDAO dao) {
    final Coupon c4 = new Coupon();
    new Expectations() {
      {
        System.out.println("mocked get Offers");
        CouponFactory.endcoupondate(1);
        result = c4;
      }
    };
    new MockUp<CouponFactory>() {
      @Mock
      CouponDAO dao() {
        System.out.println("Mocked Offers Dao");
        return dao;
      }
    };
    Date offers = CouponFactory.endcoupondate(1);
    assertNotEquals(c4, offers);
  }

  /**
   * tests that customer wallet is handled correctly.
   * @param dao mocking the dao class
   */
  @Test

  public final void showOffer(@Mocked final CouponDAO dao) {

    final Coupon offers = new Coupon();
    new Expectations() {
      {
        System.out.println("Mocked display offers");
        CouponFactory.showOffers();
        result = offers;
      }
    };
    new MockUp<CouponFactory>() {
      @Mock
      CouponDAO dao() {
        System.out.println("Mocked offers Dao");
        return dao;
      }
    };
    Coupon[] actualS = CouponFactory.showOffers();
    assertNotEquals(offers, actualS);
  }
  /**
  * default constructor testing.
 */
  @Test
public final void testDefaultConstructor() {
    CouponFactory mf = new CouponFactory();
    CouponFactory mf1 = new CouponFactory();
    assertNotEquals(mf.hashCode(), mf1.hashCode());
  }
/**
 * constructor testing.
 */
  @Test
  public final void testParameterisedCustomer() {
    Date date1 = new Date();
    Date date2 = new Date();
    Coupon coupon = new Coupon("FREE10", date1, date2, 2);
    assertEquals("FREE10", coupon.getCpnCode());
    assertEquals(date1, coupon.getcpnDate());
    assertEquals(date2, coupon.getcpnEndDate());
    assertEquals(2, coupon.getCusId());
  }
  /**
   * To test getters and setters.
   */
  @Test
  public final void testCustomerSetPoint() {
    Date date1 = new Date();
    Date date2 = new Date();
    Coupon newcustomer = new Coupon("FREE10", date1, date2, 2);
    newcustomer.setCusId(2);
    assertEquals(2, newcustomer.getCusId());
  }
}
