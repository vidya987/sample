package com.hexaware.MLP194.factory;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import java.util.ArrayList;
import com.hexaware.MLP194.model.Menu;
import com.hexaware.MLP194.persistence.MenuDAO;
import org.junit.Test;
import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
//This class test Factory class of Car
/**
 * to get details of Customer.
 */
public class MenuFactoryTest {

   /**
  * default constructor testing.
 */
  @Test
  public final void testDefaultConstructor() {
    MenuFactory mf = new MenuFactory();
    MenuFactory mf1 = new MenuFactory();
    assertNotEquals(mf.hashCode(), mf1.hashCode());
  }

   /**
  * @param dao to get dao details.
 */
  @Test
  public final void testGetAllMenu(@Mocked final MenuDAO dao) {
    final Menu menu = new Menu(10001, "Dosa", 45, "Plain Dosa", 2);
    final ArrayList<Menu> menuList = new ArrayList<Menu>();
    new Expectations() {
      {
        menuList.add(menu);
        dao.show();
        result = menuList;
      }
    };

    new MockUp<MenuFactory>() {
      @Mock
      MenuDAO dao() {
        return dao;
      }
    };

    final Menu[] menuList1 = MenuFactory.showMenu();
    assertEquals(menu, menuList1[0]);

  }
  /**
   * @param dao to get dao details.
   */
  @Test
  public final void testupdateAllMenu(@Mocked final MenuDAO dao) {
    final Menu newMenu = new Menu(10001, "Dosa", 45, "Plain Dosa", 2);
    final int i = dao.updateAmount(45, 10001);
    new Expectations() {
      {
        System.out.println("mocked get Menu login");
        dao.updateAmount(45, 10001);
        result = i;
      }
    };
    new MockUp<MenuFactory>() {
      @Mock
      MenuDAO dao() {
        return dao;
      }
    };
    final int menuList2 = MenuFactory.updatingAmount(newMenu);
    assertEquals(i, menuList2);
  }
     /**
   * @param dao to test detecting balance.
   */
  @Test
  public final void customerCouponOffers(@Mocked final MenuDAO dao) {
    final int i = dao.customerCoupon(10003);
    new Expectations() {
      {
        dao.customerCoupon(10003);
        result = i;
      }
    };
    new MockUp<MenuFactory>() {
      @Mock
      MenuDAO dao() {
        System.out.println("Mocked Customer Dao");
        return dao;
      }
    };
    int w8 = MenuFactory.validatingOrderCouponMenu(10003);
    assertEquals(i, w8);
  }
/**
 * constructor testing.
 */
  @Test
public final void testParameterisedMenu() {
    Menu menu = new Menu(10001, "Dosa", 45, "Plain Dosa", 2);
    assertEquals(10001, menu.getItmId());
    assertEquals("Dosa", menu.getItmName());
    assertEquals(45, menu.getPrice());
    assertEquals("Plain Dosa", menu.getPriDes());
    assertEquals(2, menu.getQty());
  }
/**
 * To test getters and setters.
 */
  @Test
public final void testMenuSetPoint() {
    Menu menu1 = new Menu(10001, "Dosa", 45, "Plain Dosa", 2);
    menu1.setItmId(10005);
    assertEquals(10005, menu1.getItmId());
  }
}


