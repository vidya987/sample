package com.hexaware.MLP194.model;

import com.hexaware.MLP194.persistence.OrdersDAO;
import com.hexaware.MLP194.factory.OrdersFactory;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;
import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import mockit.integration.junit4.JMockit;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 * Test class for Customer.
 */
@RunWith(JMockit.class)
public class OrdersTest {
  private Date d1 = new Date();
  private Date d2 = new Date();
  private SimpleDateFormat sdf;
  //private Orders ord;
    /**
   * setup method.
   */
  /**
   * @throws ParseException for exception.
   */
  @Before
  public final void initInput() throws ParseException {
    //ord = new Orders();
    String date1 = "2020/09/09";
    String date2 = "2020/07/05";
    sdf = new SimpleDateFormat("yyyy/MM/dd");
    sdf.setLenient(false);
    d1 = sdf.parse(date1);
    d2 = sdf.parse(date2);
  }
  /**
   * Tests the equals/hashcode methods of the employee class.
   */

  @Test
    public final void testOrdersEquals() {
    Orders c0 = new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1);
    Orders c1 = new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1);
    assertNotEquals(c0, null);
    assertNotEquals(c1, null);
    assertEquals(c0.getOrdId(),
          new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1).getOrdId());
    assertEquals(c0.getStatus(),
          new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1).getStatus());
    assertEquals(c0.getCusId(),
          new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1).getCusId());
    assertEquals(c0.getVdrId(),
          new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1).getVdrId());
    assertEquals(c0.gettoken(),
          new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1).gettoken());
    assertEquals(c0.getItemId(),
          new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1).getItemId());
    assertEquals(c0.getOrdDate(),
          new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1).getOrdDate());
    c1.setOrdId(123);
    c1.setStatus("ORDERED");
    c1.setCusId(1);
    c1.setVdrId(5100);
    c1.settoken(53);
    c1.setItemId(10001);
    c1.setOrdDate(d1);
    assertNotEquals(c1, new Orders(127, "NOT ORDERED", 2, 5400, 52, 10002, d2));
    assertEquals(c0.hashCode(),
          new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1).hashCode());
    assertEquals(c0, new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1));
  }
  /**
   * Tests the equals/hashcode methods of the employee class.
   */
  @Test
  public final void testOrders() {
    Orders c100 = new Orders();
    Orders c101 = new Orders();
    assertNotEquals(c100, null);
    assertNotEquals(c101, null);
    assertEquals(c100.getOrdId(), new Orders().getOrdId());
    c101.setCusId(100);
    assertNotEquals(c101, new Orders());
    assertEquals(c100.hashCode(), new Orders().hashCode());
    assertEquals(c100, new Orders());
  }
  /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllEmpty(@Mocked final OrdersDAO dao) {
    new Expectations() {
      {
        dao.showit();
        result = new ArrayList<Menu>();
      }
    };
    new MockUp<OrdersFactory>() {
      @Mock
      OrdersDAO dao() {
        return dao;
      }
    };
    Orders[] me = OrdersFactory.showMenu();
    assertEquals(0, me.length);
  }
  /**
   * Tests that a list with some employees is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllSome(@Mocked final OrdersDAO dao) {
    final Orders c100 = new Orders();
    final Orders c101 = new Orders();
    final ArrayList<Orders> mn = new ArrayList<Orders>();
    new Expectations() {
      {
        mn.add(c100);
        mn.add(c101);
        dao.showit();
        result = mn;
      }
    };
    new MockUp<OrdersFactory>() {
      @Mock
      OrdersDAO dao() {
        return dao;
      }
    };
    Orders[] mn1 = OrdersFactory.showMenu();
    assertEquals(2, mn1.length);
    assertEquals(new Orders().getOrdId(),
        mn1[0].getOrdId());
    assertEquals(new Orders().getOrdId(),
        mn1[1].getOrdId());
  }
    /**
   * to test the getters for vendor.
   */
  @Test
  public final void testGettersOrders() {
    Orders orders = new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1);
    assertEquals(123, orders.getOrdId());
    assertEquals("ORDERED", orders.getStatus());
    assertEquals(1, orders.getCusId());
    assertEquals(5100, orders.getVdrId());
    assertEquals(53, orders.gettoken());
    assertEquals(10001, orders.getItemId());
    assertEquals(d1, orders.getOrdDate());

  }
     /**
   * to test the setters for vendor.
   */
  @Test
  public final void testSettersOrders() {
    Orders orders = new Orders(123, "ORDERED", 1, 5100, 53, 10001, d1);
    orders.setOrdId(123);
    assertEquals(123, orders.getOrdId());
    orders.setStatus("ORDERED");
    assertEquals("ORDERED", orders.getStatus());
    orders.setCusId(1);
    assertEquals(1, orders.getCusId());
    orders.setVdrId(5100);
    assertEquals(5100, orders.getVdrId());
    orders.settoken(53);
    assertEquals(53, orders.gettoken());
    orders.setOrdDate(d1);
    assertEquals(d1, orders.getOrdDate());
  }
}
