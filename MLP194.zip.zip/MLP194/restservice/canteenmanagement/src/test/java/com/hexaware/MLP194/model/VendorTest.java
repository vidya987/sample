package com.hexaware.MLP194.model;
import com.hexaware.MLP194.persistence.VendorDAO;
import com.hexaware.MLP194.factory.VendorFactory;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;
import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import mockit.integration.junit4.JMockit;
import java.util.ArrayList;

 /**
 * Test class for Vendor.
 */
@RunWith(JMockit.class)
public class VendorTest {
    /**
   * setup method.
   */
  @Before
  public void initInput() {

  }
  /**
   * Tests the equals/hashcode methods of the employee class.
   */

  @Test
    public final void testVendorEquals() {
    Vendor c0 = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    Vendor c1 = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    assertNotEquals(c0, null);
    assertNotEquals(c1, null);
    assertEquals(c0.getSpl(),
          new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L).getSpl());
    assertEquals(c0.getStatus(),
          new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L).getStatus());
    assertEquals(c0.getVdrId(),
          new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L).getVdrId());
    assertEquals(c0.getPswd(),
          new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L).getPswd());
    assertEquals(c0.getPhnNo(),
          new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L).getPhnNo());
    c1.setSpl("Chef-nonveg");
    c1.setStatus("ORDERED");
    c1.setVdrId(5100);
    c1.setPswd("flower1234");
    c1.setPhnNo(9443408211L);
    assertNotEquals(c1, new Vendor("Chef-veg", "NOT ORDERED", 5800, "dolphin1234", 9764308211L));
    assertEquals(c0.hashCode(),
          new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L).hashCode());
    assertEquals(c0, new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L));
  }
   /**
   * Tests the equals/hashcode methods of the employee class.
   */
  @Test
  public final void testVendor() {

    Vendor m100 = new Vendor();
    Vendor m101 = new Vendor();
    assertNotEquals(m100, null);
    assertNotEquals(m101, null);
    assertEquals(m100.getVdrId(),
        new Vendor().getVdrId());
    m101.setVdrId(100);
    assertNotEquals(m101, new Vendor());
    assertEquals(m100.hashCode(),
        new Vendor().hashCode());
    assertEquals(m100, new Vendor());
  }
  /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllEmpty(@Mocked final VendorDAO dao) {
    new Expectations() {
      {
        dao.show(); result = new ArrayList<Vendor>();
      }
    };
    new MockUp<VendorFactory>() {
      @Mock
      VendorDAO dao() {
        return dao;
      }
    };
    Vendor[] me = VendorFactory.showVendor();
    assertEquals(0, me.length);
  }
  /**
   * Tests that a list with some employees is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllSome(@Mocked final VendorDAO dao) {
    final Vendor m100 = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    final Vendor m101 = new Vendor("Chef-nonveg", "PENDING", 5101, "garden1234", 9632587412L);
    final ArrayList<Vendor> mn = new ArrayList<Vendor>();
    new Expectations() {
      {
        mn.add(m100);
        mn.add(m101);
        dao.show(); result = mn;
      }
    };
    new MockUp<VendorFactory>() {
      @Mock
      VendorDAO dao() {
        return dao;
      }
    };
    Vendor[] mn1 = VendorFactory.showVendor();
    assertEquals(2, mn1.length);
    assertEquals(new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L).getVdrId(),
        mn1[0].getVdrId());
    assertEquals(new Vendor("Chef-nonveg", "PENDING", 5101, "garden1234", 9632587412L).getVdrId(),
        mn1[1].getVdrId());
  }
  /**
   * to test the getters for vendor.
   */
  @Test
  public final void testGettersVendors() {
    Vendor vendor = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    assertEquals("Chef-nonveg", vendor.getSpl());
    assertEquals("ORDERED", vendor.getStatus());
    assertEquals(5100, vendor.getVdrId());
    assertEquals("flower1234", vendor.getPswd());
    assertEquals(9443408211L, vendor.getPhnNo());

  }

   /**
   * to test the setters for vendor.
   */
  @Test
  public final void testSettersVendors() {
    Vendor vendor = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    vendor.setSpl("Chef-nonveg");
    assertEquals("Chef-nonveg", vendor.getSpl());
    vendor.setStatus("ORDERED");
    assertEquals("ORDERED", vendor.getStatus());
    vendor.setVdrId(5100);
    assertEquals(5100, vendor.getVdrId());
    vendor.setPswd("flower1234");
    assertEquals("flower1234", vendor.getPswd());
    vendor.setPhnNo(9443408211L);
    assertEquals(9443408211L, vendor.getPhnNo());
  }
}
