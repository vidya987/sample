package com.hexaware.MLP194.model;
import com.hexaware.MLP194.persistence.MenuDAO;
import com.hexaware.MLP194.factory.MenuFactory;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;
import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import mockit.integration.junit4.JMockit;
import java.util.ArrayList;

/**
 * Test class for Menu.
 */
@RunWith(JMockit.class)
public class MenuTest {
    /**
   * setup method.
   */
  @Before
  public void initInput() {
  }
  /**
   * Tests the equals/hashcode methods of the employee class.
   */
  @Test
    public final void testMenuEquals() {
    Menu c0 = new Menu(10001, "Dosa", 45, "Plain Dosa", 2);
    Menu c1 = new Menu(10001, "Dosa", 45, "Plain Dosa", 2);
    assertNotEquals(c0, null);
    assertNotEquals(c1, null);
    assertEquals(c0.getItmId(),
          new Menu(10001, "Dosa", 45, "Plain Dosa", 2).getItmId());
    assertEquals(c0.getItmName(),
          new Menu(10001, "Dosa", 45, "Plain Dosa", 2).getItmName());
    assertEquals(c0.getPrice(),
          new Menu(10001, "Dosa", 45, "Plain Dosa", 2).getPrice());
    assertEquals(c0.getPriDes(),
          new Menu(10001, "Dosa", 45, "Plain Dosa", 2).getPriDes());
    assertEquals(c0.getQty(),
          new Menu(10001, "Dosa", 45, "Plain Dosa", 2).getQty());
    c1.setItmId(10001);
    c1.setItmName("Dosa");
    c1.setPrice(45);
    c1.setPriDes("Plain Dosa");
    c1.setQty(2);
    assertNotEquals(c1, new Menu(10005, "idly", 47, "Rava idly", 3));
    assertEquals(c0.hashCode(),
          new Menu(10001, "Dosa", 45, "Plain Dosa", 2).hashCode());
    assertEquals(c0, new Menu(10001, "Dosa", 45, "Plain Dosa", 2));
  }
   /**
   * Tests the equals/hashcode methods of the employee class.
   */
  @Test
  public final void testMenu() {

    Menu m100 = new Menu();
    Menu m101 = new Menu();
    assertNotEquals(m100, null);
    assertNotEquals(m101, null);
    assertEquals(m100.getItmId(), new Menu().getItmId());
    m101.setItmId(100);
    assertNotEquals(m101, new Menu());
    assertEquals(m100.hashCode(), new Menu().hashCode());
    assertEquals(m100, new Menu());
  }
  /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllEmpty(@Mocked final MenuDAO dao) {
    new Expectations() {
      {
        dao.show(); result = new ArrayList<Menu>();
      }
    };
    new MockUp<MenuFactory>() {
      @Mock
      MenuDAO dao() {
        return dao;
      }
    };
    Menu[] me = MenuFactory.showMenu();
    assertEquals(0, me.length);
  }
  /**
   * Tests that a list with some employees is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllSome(@Mocked final MenuDAO dao) {
    final Menu m100 = new Menu(100, null, 0, null, 0);
    final Menu m101 = new Menu(101, null, 0, null, 0);
    final ArrayList<Menu> mn = new ArrayList<Menu>();
    new Expectations() {
      {
        mn.add(m100);
        mn.add(m101);
        dao.show(); result = mn;
      }
    };
    new MockUp<MenuFactory>() {
      @Mock
      MenuDAO dao() {
        return dao;
      }
    };
    Menu[] mn1 = MenuFactory.showMenu();
    assertEquals(2, mn1.length);
    assertEquals(new Menu(100, null, 0, null, 0).getItmId(),
        mn1[0].getItmId());
    assertEquals(new Menu(101, null, 0, null, 0).getItmId(),
        mn1[1].getItmId());
  }
  /**
   * to test the getters for vendor.
   */
  @Test
  public final void testGettersMenu() {
    Menu menu = new Menu(10002, "Chapathi", 20, "Variety falvoured Chapathi", 3);
    assertEquals(10002, menu.getItmId());
    assertEquals("Chapathi", menu.getItmName());
    assertEquals(20, menu.getPrice());
    assertEquals("Variety falvoured Chapathi", menu.getPriDes());
    assertEquals(3, menu.getQty());
  }
     /**
   * to test the setters for vendor.
   */
  @Test
  public final void testSettersMenu() {
    Menu menu = new Menu(10002, "Chapathi", 20, "Variety falvoured Chapathi", 3);
    menu.setItmId(10002);
    assertEquals(10002, menu.getItmId());
    menu.setItmName("Chapathi");
    assertEquals("Chapathi", menu.getItmName());
    menu.setPrice(20);
    assertEquals(20, menu.getPrice());
    menu.setPriDes("Variety falvoured Chapathi");
    assertEquals("Variety falvoured Chapathi", menu.getPriDes());
    menu.setQty(3);
    assertEquals(3, menu.getQty());
  }
}
