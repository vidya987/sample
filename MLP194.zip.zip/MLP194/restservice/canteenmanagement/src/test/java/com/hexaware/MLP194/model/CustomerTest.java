package com.hexaware.MLP194.model;
import com.hexaware.MLP194.persistence.CustomerDAO;
import com.hexaware.MLP194.factory.CustomerFactory;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;
import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import mockit.integration.junit4.JMockit;
import java.util.ArrayList;

/**
 * Test class for Customer.
 */
@RunWith(JMockit.class)
public class CustomerTest {
  /**
   * setup method.
   */
  @Before
  public void initInput() {
  }
  /**
   * Tests the equals/hashcode methods of the employee class.
   */
  @Test
    public final void testCustomer() {
    Customer c0 = new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000);
    Customer c1 = new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000);
    assertNotEquals(c0, null);
    assertNotEquals(c1, null);
    assertEquals(c0.getCusId(),
          new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000).getCusId());
    assertEquals(c0.getWalNo(),
          new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000).getWalNo());
    assertEquals(c0.getPhnNo(),
          new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000).getPhnNo());
    assertEquals(c0.getAddRess(),
          new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000).getAddRess());
    assertEquals(c0.getCrdNo(),
          new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000).getCrdNo());
    assertEquals(c0.getPswd(),
          new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000).getPswd());
    assertEquals(c0.getbalance(),
          new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000).getbalance());
    c1.setCusId(6);
    c1.setWalNo(1221);
    c1.setPhnNo(9600340997L);
    c1.setAddRess("karapakkam");
    c1.setCrdNo(103);
    c1.setPswd("thankgod2");
    c1.setbalance(15000);
    assertNotEquals(c1, new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000));
    assertEquals(c0.hashCode(),
          new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000).hashCode());
    assertEquals(c0, new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000));
  }
  /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllEmpty(@Mocked final CustomerDAO dao) {
    new Expectations() {
      {
        dao.show(); result = new ArrayList<Menu>();
      }
    };
    new MockUp<CustomerFactory>() {
      @Mock
      CustomerDAO dao() {
        return dao;
      }
    };
    Customer[] me = CustomerFactory.showCustomer();
    assertEquals(0, me.length);
  }
  /**
   * Tests that a list with some employees is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllSome(@Mocked final CustomerDAO dao) {
    final Customer c100 = new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 10000);
    final Customer c101 = new Customer(2, 1222, 9486627946L, "medavakkam", 102, "welcome123", 12000);
    final ArrayList<Customer> mn = new ArrayList<Customer>();
    new Expectations() {
      {
        mn.add(c100);
        mn.add(c101);
        dao.show(); result = mn;
      }
    };
    new MockUp<CustomerFactory>() {
      @Mock
      CustomerDAO dao() {
        return dao;
      }
    };
    Customer[] mn1 = CustomerFactory.showCustomer();
    assertEquals(2, mn1.length);
    assertEquals(new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 10000).getCusId(),
        mn1[0].getCusId());
    assertEquals(new Customer(2, 1222, 9486627946L, "medavakkam", 102, "welcome123", 12000).getCusId(),
        mn1[1].getCusId());
  }
  /**
   * to check default Constructor.
   */
  @Test
  public final void defaultConstructor() {
    Customer customer = new Customer();
    assertEquals(customer.hashCode(), new Customer().hashCode());
    customer.setCusId(12);
    assertNotEquals(customer.getCusId(), new Customer().getCusId());
  }
  /**
   * to check Parameterized Constructor.
   */
  @Test
  public final void testParamConstructor() {
    Customer customer = new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 10000);
    assertEquals(1, customer.getCusId());
    assertEquals(1221, customer.getWalNo());
    assertEquals(9600340997L, customer.getPhnNo());
    assertEquals("karapakkam", customer.getAddRess());
    assertEquals(103, customer.getCrdNo());
    assertEquals("thankgod2", customer.getPswd());
    assertEquals(10000, customer.getbalance());
  }
    /**
   * to test the getters for vendor.
   */
  @Test
  public final void testGettersCustomer() {
    Customer customer = new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 10000);
    assertEquals(1, customer.getCusId());
    assertEquals(1221, customer.getWalNo());
    assertEquals(9600340997L, customer.getPhnNo());
    assertEquals("karapakkam", customer.getAddRess());
    assertEquals(103, customer.getCrdNo());
    assertEquals("thankgod2", customer.getPswd());
    assertEquals(10000, customer.getbalance());
  }
     /**
   * to test the setters for vendor.
   */
  @Test
  public final void testSettersVendors() {
    Customer customer = new Customer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 10000);
    customer.setCusId(1);
    assertEquals(1, customer.getCusId());
    customer.setWalNo(1221);
    assertEquals(1221, customer.getWalNo());
    customer.setPhnNo(9600340997L);
    assertEquals(9600340997L, customer.getPhnNo());
    customer.setAddRess("karapakkam");
    assertEquals("karapakkam", customer.getAddRess());
    customer.setCrdNo(103);
    assertEquals(103, customer.getCrdNo());
    customer.setPswd("thankgod2");
    assertEquals("thankgod2", customer.getPswd());
    customer.setbalance(10000);
    assertEquals(10000, customer.getbalance());

  }
}
