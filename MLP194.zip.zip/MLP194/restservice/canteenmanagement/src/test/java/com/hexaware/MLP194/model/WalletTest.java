package com.hexaware.MLP194.model;
import com.hexaware.MLP194.persistence.WalletDAO;
import com.hexaware.MLP194.factory.WalletFactory;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;
import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import mockit.integration.junit4.JMockit;
import java.util.ArrayList;

/**
 * Test class for Wallet.
 */
@RunWith(JMockit.class)
public class WalletTest {
    /**
   * setup method.
   */
  @Before
  public void initInput() {
  }
   /**
   * Tests the equals/hashcode methods of the employee class.
   */

  @Test
    public final void testWalletEquals() {
    Wallet c0 = new Wallet(6, 7, 1, 5000);
    Wallet c1 = new Wallet(6, 7, 1, 5000);
    assertNotEquals(c0, null);
    assertNotEquals(c1, null);
    assertEquals(c0.getwltPt(),
          new Wallet(6, 7, 1, 5000).getwltPt());
    assertEquals(c0.getwltNo(),
          new Wallet(6, 7, 1, 5000).getwltNo());
    assertEquals(c0.getCusId(),
          new Wallet(6, 7, 1, 5000).getCusId());
    assertEquals(c0.getbalance(),
          new Wallet(6, 7, 1, 5000).getbalance());
    c1.setwltPt(6);
    c1.setwltNo(7);
    c1.setCusId(1);
    c1.setamouNt(5000);
    assertNotEquals(c1, new Wallet(8, 2, 3, 6000));
    assertEquals(c0.hashCode(),
          new Wallet(6, 7, 1, 5000).hashCode());
    assertEquals(c0, new Wallet(6, 7, 1, 5000));
  }
    /**
   * Tests the equals/hashcode methods of the employee class.
   */

  @Test
  public final void testWallet() {

    Wallet w10 = new Wallet();
    Wallet w11 = new Wallet();
    assertNotEquals(w10, null);
    assertNotEquals(w11, null);
    assertEquals(w10.getwltPt(), new Wallet().getwltPt());
    w11.setwltPt(100);
    assertNotEquals(w11, new Wallet());
    assertEquals(w10.hashCode(), new Wallet().hashCode());
    assertEquals(w10, new Wallet());
  }
  /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllEmpty(@Mocked final WalletDAO dao) {
    new Expectations() {
      {
        dao.show(); result = new ArrayList<Wallet>();
      }
    };
    new MockUp<WalletFactory>() {
      @Mock
      WalletDAO dao() {
        return dao;
      }
    };
    Wallet[] me = WalletFactory.showMenu();
    assertEquals(0, me.length);
  }
  /**
   * Tests that a list with some employees is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllSome(@Mocked final WalletDAO dao) {
    final Wallet w10 = new Wallet(6, 1221, 1, 500);
    final Wallet w11 = new Wallet(7, 1222, 2, 600);
    final ArrayList<Wallet> mn = new ArrayList<Wallet>();
    new Expectations() {
      {
        mn.add(w10);
        mn.add(w11);
        dao.show(); result = mn;
      }
    };
    new MockUp<WalletFactory>() {
      @Mock
      WalletDAO dao() {
        return dao;
      }
    };
    Wallet[] mn1 = WalletFactory.showMenu();
    assertEquals(2, mn1.length);
    assertEquals(new Wallet(6, 1221, 1, 500).getwltPt(),
        mn1[0].getwltPt());
    assertEquals(new Wallet(7, 1222, 2, 600).getwltPt(),
        mn1[1].getwltPt());
  }
    /**
   * to test the getters for vendor.
   */
  @Test
  public final void testGettersWallet() {
    Wallet wallet = new Wallet(6, 1221, 1, 500);
    assertEquals(6, wallet.getwltPt());
    assertEquals(1221, wallet.getwltNo());
    assertEquals(1, wallet.getCusId());
    assertEquals(500, wallet.getbalance());
  }
     /**
   * to test the setters for vendor.
   */
  @Test
  public final void testSettersVendors() {
    Wallet wallet = new Wallet(6, 1221, 1, 500);
    wallet.setwltPt(6);
    assertEquals(6, wallet.getwltPt());
    wallet.setwltNo(1221);
    assertEquals(1221, wallet.getwltNo());
    wallet.setCusId(1);
    assertEquals(1, wallet.getCusId());
    wallet.setamouNt(500);
    assertEquals(500, wallet.getbalance());
  }
}
