package com.hexaware.MLP194.factory;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import com.hexaware.MLP194.model.Orders;
import com.hexaware.MLP194.persistence.OrdersDAO;
import org.junit.Before;
import org.junit.Test;
import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
/**
 * to get details of Orders.
 */
//This class test Factory class of Car
public class OrdersFactoryTest {

  private Date d1 = new Date();
  private DateFormat sdf;
/**
 * @throws ParseException to parse the Date.
 */
  @Before
    public final void initInput() throws ParseException {
  }
/**
 * @param dao to get dao details.
 */
  @Test
  public final void testGetAllOrders(@Mocked final OrdersDAO dao) {
    Date pdate = new Date();
    final Orders dosa = new Orders(123, "ORDERED", 1, 5100, 53, 10001, pdate);
    final ArrayList<Orders> ordersList = new ArrayList<Orders>();
    new Expectations() {
      {
        ordersList.add(dosa);
        dao.showit();
        result = ordersList;
      }
    };
    new MockUp<OrdersFactory>() {

      @Mock
      OrdersDAO dao() {
          return dao;
      }
    };
    Orders[] ordersList1 = OrdersFactory.showMenu();
    assertEquals(dosa, ordersList1[0]);
  }
   /**
   * @param dao  to get dao details.
   * @throws ParseException throws Exception.
   */
  @Test
  public final void insertingOrders(@Mocked final OrdersDAO dao) throws ParseException {
    String date1 = "2019-09-09";
    sdf = new SimpleDateFormat("yyyy-MM-dd");
    sdf.setLenient(false);
    d1 = sdf.parse(date1);
    final java.sql.Date sdate = new java.sql.Date(d1.getTime());
    new Expectations() {
      {
        dao.placeOrders(123, "ORDERED", 1, 5100, 53, 10001, sdate);
        result = 1;
      }
    };
    new MockUp<OrdersFactory>() {
      @Mock
      OrdersDAO dao() {
        return dao;
      }
    };
    int oi1 = OrdersFactory.insertingOrders(123, "ORDERED", 1, 5100, 53, d1, 10001);
    assertEquals(1, oi1);
  }
  /**
   * @param dao to get dao details.
   * @throws ParseException to parse.
   */
  @Test
  public final void updatingOrders(@Mocked final OrdersDAO dao) throws ParseException {
    final int i = dao.updateOrders("status", 123);
    new Expectations() {
      {
        dao.updateOrders("status", 123);
        result = 0;
      }
    };
    new MockUp<OrdersFactory>() {

      @Mock
      OrdersDAO dao() {
          return dao;
      }
    };
    int w3 = OrdersFactory.updatingOrders("status", 123);
    assertEquals(i, w3);
  }
    /**
     * @param dao to get dao details.
     * @throws ParseException to parse.
     */
  @Test
    public final void orderStatus(@Mocked final OrdersDAO dao) throws ParseException {
    final Orders i = dao.orderStatus(12);
    new Expectations() {
        {
          dao.orderStatus(12);
          result = i;
        }
      };
    new MockUp<OrdersFactory>() {
        @Mock
        OrdersDAO dao() {
            return dao;
        }
      };
    final Orders w4 = OrdersFactory.orderingStatus(12);
    assertEquals(i, w4);
  }
  /**
   * @param dao to get dao details.
   */
  @Test
public final void validatingCouponOrder(@Mocked final OrdersDAO dao) {
    final int i = dao.checkcoup(2);
    new Expectations() {
      {
        dao.checkcoup(2);
        result = i;
      }
    };
    new MockUp<OrdersFactory>() {

      @Mock
      OrdersDAO dao() {
          return dao;
      }
    };
    final int w9 = OrdersFactory.validatingOrderCoupon(2);
    assertEquals(i, w9);
  }
   /**
    * @param dao to get dao details.
    * @throws ParseException to handle Exception.
    */
  @Test
   public final void orderOffer(@Mocked final OrdersDAO dao) throws ParseException {
    String date1 = "2019-09-09";
    sdf = new SimpleDateFormat("yyyy-MM-dd");
    sdf.setLenient(false);
    d1 = sdf.parse(date1);
    final java.sql.Date sd = new java.sql.Date(d1.getTime());
    final int i = dao.addOrderoff(1, 10001, sd);
    new Expectations() {
      {
        dao.addOrderoff(1, 10001, sd);
        result = i;
      }
    };
    new MockUp<OrdersFactory>() {

      @Mock
      OrdersDAO dao() {
          return dao;
      }
    };
    final int w9 = OrdersFactory.addOrdersoff(1, 10001, d1);
    assertEquals(i, w9);
  }
/**
  * default constructor testing.
 */
  @Test
public final void testDefaultConstructor() {
    OrdersFactory mf = new OrdersFactory();
    OrdersFactory mf1 = new OrdersFactory();
    assertNotEquals(mf.hashCode(), mf1.hashCode());
  }

/**
 * constructor testing.
 */
  @Test
public final void testParameterisedOrders() {
    Date date2 = new Date();
    Orders order = new Orders(123, "ORDERED", 1, 5100, 53, 10001, date2);
    assertEquals(123, order.getOrdId());
    assertEquals("ORDERED", order.getStatus());
    assertEquals(1, order.getCusId());
    assertEquals(5100, order.getVdrId());
    assertEquals(53, order.gettoken());
    assertEquals(10001, order.getItemId());
    assertEquals(date2, order.getOrdDate());
  }
/**
 * To test getters and setters.
 */
  @Test
public final void testCustomerSetPoint() {
    Date date2 = new Date();
    Orders order = new Orders(123, "ORDERED", 1, 5100, 53, 10001, date2);
    order.setOrdId(15);
    assertEquals(15, order.getOrdId());
  }
}

