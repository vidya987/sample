package com.hexaware.MLP194.model;
import com.hexaware.MLP194.persistence.CouponDAO;
import com.hexaware.MLP194.factory.CouponFactory;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;
import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import mockit.integration.junit4.JMockit;
import java.util.ArrayList;

/**
 * Test class for offers.
 */
@RunWith(JMockit.class)
public class CouponTest {
    /**
   * setup method.
   */
  @Before
  public void initInput() {

  }
  /**
   * Tests the equals/hashcode methods of the employee class.
   */
  @Test
  public final void testOffers() {
    Coupon o1 = new Coupon();
    Coupon o2 = new Coupon();
    assertNotEquals(o1, null);
    assertNotEquals(o2, null);
    assertEquals(o1.getCusId(), new Coupon().getCusId());
    o2.setCusId(5);
    assertNotEquals(o2, new Coupon());
    assertEquals(o1.hashCode(),
        new Coupon().hashCode());
    assertEquals(o1, new Coupon());
  }
  /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllEmpty(@Mocked final CouponDAO dao) {
    new Expectations() {
      {
        dao.show(); result = new ArrayList<Coupon>();
      }
    };
    new MockUp<CouponFactory>() {
      @Mock
      CouponDAO dao() {
        return dao;
      }
    };
    Coupon[] me = CouponFactory.showOffers();
    assertEquals(0, me.length);
  }
  /**
   * Tests that a list with some employees is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllSome(@Mocked final CouponDAO dao) {
    final Coupon o1 = new Coupon();
    final Coupon o2 = new Coupon();
    final ArrayList<Coupon> mn = new ArrayList<Coupon>();
    new Expectations() {
      {
        mn.add(o1);
        mn.add(o2);
        dao.show(); result = mn;
      }
    };
    new MockUp<CouponFactory>() {
      @Mock
    CouponDAO dao() {
        return dao;
      }
    };
    Coupon[] mn1 = CouponFactory.showOffers();
    assertEquals(2, mn1.length);
    assertEquals(new Coupon().getCusId(),
        mn1[0].getCusId());
    assertEquals(new Coupon().getCusId(),
        mn1[1].getCusId());
  }
}
