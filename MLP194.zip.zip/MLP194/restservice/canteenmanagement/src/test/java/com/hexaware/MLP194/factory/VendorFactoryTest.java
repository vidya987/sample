package com.hexaware.MLP194.factory;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import java.util.ArrayList;
import com.hexaware.MLP194.model.Vendor;
import com.hexaware.MLP194.persistence.VendorDAO;
import org.junit.Test;
import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;

//This class test Factory class of Car
/**
 * to get details of Customer.
 */
public class VendorFactoryTest {
 /**
  * @param dao to get dao details.
 */
  @Test
  public final void testGetAllCustomer(@Mocked final VendorDAO dao) {
    final Vendor v = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    final ArrayList<Vendor> vendorList = new ArrayList<Vendor>();
    new Expectations() {
      {
        vendorList.add(v);
        dao.show();
        result = vendorList;
      }
    };
    new MockUp<VendorFactory>() {
        @Mock
        VendorDAO dao() {
          return dao;
        }
      };
    final Vendor[] vendorList1 = VendorFactory.showVendor();
    assertNotEquals(0, vendorList1[0]);
  }

  /**
   * @param dao to get dao details.
   */
  @Test
  public final void testInsertAllVendor(@Mocked final VendorDAO dao) {
    //Vendor newVendor = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    final int i = dao.insertVendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    new Expectations() {
      {
        System.out.println("mocked get Vendor login");
        dao.insertVendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
        result = i;
      }
    };
    new MockUp<VendorFactory>() {

      @Mock
      VendorDAO dao() {
        return dao;
      }
    };

    final int vendorList2 = VendorFactory.insertingVendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    assertEquals(i, vendorList2);
  }

  /**
   * @param dao to get dao details.
   */
  @Test
  public final void testupdateAllVendor(@Mocked final VendorDAO dao) {
    //Vendor newVendor = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    final int i = dao.updateVendor("Chef-nonveg", 5100);
    new Expectations() {
      {
        System.out.println("mocked get Vendor login");
        dao.updateVendor("Chef-nonveg", 5100);
        result = i;
      }
    };
    new MockUp<VendorFactory>() {
      @Mock
      VendorDAO dao() {
        return dao;
      }
    };
    final int vendorList2 = VendorFactory.updatingVendor("Chef-nonveg", 5100);
    assertEquals(i, vendorList2);
  }

  /**
   * @param dao to get dao details.
   */
  @Test
  public final void testValidateAllVendor(@Mocked final VendorDAO dao) {
    //Vendor newVendor = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    //final Vendor newVendors = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    final Vendor i = dao.validatingVendors(5100, "flower1234");
    new Expectations() {
      {
        System.out.println("mocked get Vendor login");
        dao.validatingVendors(5100, "flower1234");
        result = i;
      }
    };
    new MockUp<VendorFactory>() {
      @Mock
      VendorDAO dao() {
        return dao;
      }
    };
    final Vendor vendorList2 = VendorFactory.validatingVendor(5100, "flower1234");
    assertEquals(i, vendorList2);
  }
   /**
   * @param dao to get dao details.
   */
  @Test
  public final void testVendorStatus(@Mocked final VendorDAO dao) {
    //Vendor newVendor = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    //final Vendor newVendors = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    final int i = dao.updateStatus("ORDERED");
    new Expectations() {
      {
        System.out.println("mocked get Vendor");
        dao.updateStatus("ORDERED");
        result = i;
      }
    };
    new MockUp<VendorFactory>() {
      @Mock
      VendorDAO dao() {
        return dao;
      }
    };
    final int vendorList5 = VendorFactory.updateVenStatus("ORDERED");
    assertEquals(i, vendorList5);
  }
/**
  * default constructor testing.
 */
  @Test
public final void testDefaultConstructor() {
    VendorFactory mf = new VendorFactory();
    VendorFactory mf1 = new VendorFactory();
    assertNotEquals(mf.hashCode(), mf1.hashCode());
  }
  /**
 * constructor testing.
 */
  @Test
public final void testParameterisedVendor() {
    Vendor vendor = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    assertEquals("Chef-nonveg", vendor.getSpl());
    assertEquals("ORDERED", vendor.getStatus());
    assertEquals(5100, vendor.getVdrId());
    assertEquals("flower1234", vendor.getPswd());
    assertEquals(9443408211L, vendor.getPhnNo());
  }
/**
 * To test getters and setters.
 */
  @Test
public final void testMenuSetPoint() {
    Vendor vendor1 = new Vendor("Chef-nonveg", "ORDERED", 5100, "flower1234", 9443408211L);
    vendor1.setVdrId(12);
    assertEquals(12, vendor1.getVdrId());
  }
}

