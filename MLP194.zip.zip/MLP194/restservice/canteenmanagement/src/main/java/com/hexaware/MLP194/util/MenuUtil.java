package com.hexaware.MLP194.util;
import com.hexaware.MLP194.factory.MenuFactory;
import com.hexaware.MLP194.model.Menu;

/**
   * showFullMenu method display the menu item stored in database.
   */
public class MenuUtil {
/**
   * showFullMenu method display the menu item stored in database.
   */

  public final void showFullMenu() {
    final Menu[] menu = MenuFactory.showMenu();
    System.out.println("itmId" + "\t" + "itmName" + "\t" + "\t" + "\t" + "Price" + "\t" + "\t" + "Price Description" + "\t" + "Quantity");

    for (final Menu m : menu) {
      System.out.println(m.getItmId() + "\t" + m.getItmName() + "\t" + "\t" + "\t" + m.getPrice() + "\t" + "\t" + m.getPriDes() + "\t" + m.getQty());
    }
  }
}
