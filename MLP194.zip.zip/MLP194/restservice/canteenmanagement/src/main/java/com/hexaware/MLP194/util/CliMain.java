package com.hexaware.MLP194.util;
import java.text.ParseException;
import java.util.Scanner;
/**
 * CliMain used as Client interface for java coading.
 * @author hexware
 */

class CliMain {
  private final Scanner option = new Scanner(System.in, "UTF-8");

  /**
   * mainMenu method used to display the option we had in the application.
   * @throws ParseException to handle Exception.
   */
  private void mainMenu() throws ParseException {
    System.out.println("Canteen Management System");
    System.out.println("------Southern Delights------");
    System.out.println("-----------------------");
    System.out.println("1.Menu");
    System.out.println("2.Customer");
    System.out.println("3.Wallet");
    System.out.println("4.Vendor");
    System.out.println("5.Order");
    System.out.println("6. Exit");
    table();
    // mainMenu();
  }

  /**
   * to display Tables.
   * @throws ParseException to handle Exception.
   */

  public void table() throws ParseException {
    System.out.println("Enter the Option to be viewed");
    final int table = option.nextInt();
    final CustomerUtil c = new CustomerUtil();
    final VendorUtil v = new VendorUtil();
    final WalletUtil w = new WalletUtil();
    final OrdersUtil o = new OrdersUtil();
    final MenuUtil m = new MenuUtil();
    switch (table) {
      case 1:
        m.showFullMenu();
        break;
      case 2:
        c.detailsTableCustomer();
        break;
      case 3:
        w.detailsTableWallet();
        break;
      case 4:
        v.detailsTableVendor();
        break;
      case 5:
        o.detailsTableOrders();
        break;
      case 6:
        Runtime.getRuntime().halt(0);
      default:
        System.out.println("Choose either 1 or 2 or 3 or 4");
    }
  }

  /**
   * main method is the basic entry point for the application.

   * @param args used to get the user input.
   * @throws ParseException to handle Excepyion.
   */
  public static void main(final String[] args) throws ParseException {
    final CliMain mainObj = new CliMain();
    mainObj.mainMenu();
  }
}



