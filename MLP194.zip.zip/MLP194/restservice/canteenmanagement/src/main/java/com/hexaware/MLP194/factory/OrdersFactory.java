package com.hexaware.MLP194.factory;
import java.util.Date;
import java.text.ParseException;
//import java.text.SimpleDateFormat;
import java.util.List;
import com.hexaware.MLP194.persistence.DbConnection;
import com.hexaware.MLP194.persistence.OrdersDAO;
import com.hexaware.MLP194.model.Orders;
/**
 * OrdersFactory class used to fetch order data from database.
 * @author hexware
 */
public class OrdersFactory {
  /**
   *  Protected constructor.
   */
  protected OrdersFactory() {
  }
  /**
   * Call the data base connection.
   * @return the connection object.
   */
  private static OrdersDAO dao() {
    DbConnection db = new DbConnection();
    return db.getConnect().onDemand(OrdersDAO.class);
  }
  /**
   * Call the data base connection.
   * @return the array of menu object.
   */
  public static Orders[] showMenu() {
    List<Orders> orders = dao().showit();
    return orders.toArray(new Orders[orders.size()]);
  }
    /**
     * Call the data base connection.
     * @param ordId   to insert order id.
     * @param status  to insert wallet number.
     * @param cusId   to insert customer id.
     * @param vdrId   to insert vendor id.
     * @param token   to insert order history.
     * @param ordDate to insert date.
     * @param itmId   to insert id.
     * @return to insert order details.
     * @throws ParseException to handle exception.
     */
  public static int insertingOrders(final int ordId, final String status, final int cusId, final int vdrId,
        final int token, final Date ordDate, final int itmId) throws ParseException {
    //int i = dao().insertOrders(); {
    createToken();
    //SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    //final Date od = sdf.format(ordDate);
    final java.sql.Date sd = new java.sql.Date(ordDate.getTime());
    int i = dao().placeOrders(ordId, status, cusId, vdrId, token, itmId, sd);
    return i;
  }
    /*try {
      od = sdf.parse(ordDate);
      System.out.println(sdf.format(ordDate));
    } catch (ParseException e) {
      System.out.println("Enter valid Date");
    }*/
  /**
   * Call the data base connection.
   * @param ordId  to update order id.
   * @param status to update order history.
   * @return to update order details.
   */
  public static int updatingOrders(final String status, final int ordId) {
    int i = dao().updateOrders(status, ordId);
    return i;
  }
  /** Call the data base connection.
  * @param ordId to check order status.
  * @return to return order details
  */
  public static Orders orderingStatus(final int ordId) {
    Orders i = dao().orderStatus(ordId);
    return i;
  }
   /**
     * @return the token number for order
     */
  public static long createToken() {
    int token = (int) (Math.round(Math.random() * 100 + 1));
    return token;
  }

/**
 * @param cusId to validate customer id.
 * @return to return validation result.
   */
  public static int validatingOrderCoupon(final int cusId) {
    int customer = dao().checkcoup(cusId);
    return customer;
  }
   /**
     * Call the data base connection.
     * @param newOrders to get orders.
     * @return to insert order details.
     * @throws ParseException to handle exception.
     */
 /* public static int insertingOrders(final Orders newOrders) {
    int i = dao().placeOrders(newOrders.getOrdId(), newOrders.getStatus(),
        newOrders.getCusId(), newOrders.getVdrId(), newOrders.gettoken(), newOrders.getItemId(), newOrders.getOrdDate());
    return i;
  }*/
/**
     * Call the data base connection.
     * @param newOrders to get orders.
     * @return to insert order details.
     * @throws ParseException to handle exception.
     */
  /*public static int updatingOrders(final Orders newOrders) {
    int i = dao().updateOrders(newOrders.getStatus(), newOrders.getOrdId());
    return i;
  }*/
  /**
     * Call the data base connection.
     * @param newOrders to get orders.
     * @return to insert order details.
     * @throws ParseException to handle exception.
     */
  /*public static Orders orderingStatus(final Orders newOrders) {
    Orders i = dao().orderStatus(newOrders.getOrdId());
    return i;
  }
  */
    /**
   * @param itmId  for food Id.
   * @param cusId    for storing cust id.
   * @param d1 for storing date.
   * @return int
   */
  public static int addOrdersoff(final int cusId, final int itmId, final Date d1) {
    final java.sql.Date sd = new java.sql.Date(d1.getTime());
    int i = dao().addOrderoff(cusId, itmId, sd);
    return i;
  }
}


