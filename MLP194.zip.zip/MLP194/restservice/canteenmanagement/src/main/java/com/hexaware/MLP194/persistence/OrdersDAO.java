package com.hexaware.MLP194.persistence;
import java.sql.Date;
import java.util.List;
import com.hexaware.MLP194.model.Orders;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
/**
 * OrdersDAO class used to fetch data from data base.
 * @author hexware
 */
public interface OrdersDAO {
/**
   * @return the all the Wallet record.
  */
  @SqlQuery("Select * from Orders")
    @Mapper(OrdersMapper.class)
    List<Orders> showit();

/**
 * @param ordId to insert order id.
 * @param status to insert order status.
 * @param cusId to insert customer id.
 * @param vdrId to insert vendor id.
 * @param token to insert token number.
 * @param ordDate to insert order date.
 * @param itmId to insert item id.
 * @return to insert values into orders table
 */

  @SqlUpdate("INSERT INTO Orders(ODR_ID, STATUS, CUS_ID,  VDR_ID, TKN_NO, ITM_ID, ORD_DATE)"
      + "VALUES (:ordId, :status, :cusId, :vdrId, :token, :itmId , :ordDate)")
   int placeOrders(@Bind("ordId") int ordId, @Bind("status") String status, @Bind("cusId") int cusId,
      @Bind("vdrId") int vdrId,  @Bind("token") int token, @Bind("itmId") int itmId, @Bind("ordDate") Date ordDate);

/**
 * @param ordId to update order id.
 * @param status to update order status.
 * @return to return the updated order history.
 */
  @SqlUpdate("Update Orders set STATUS = :status where ODR_ID = :ordId")
    int updateOrders(@Bind("status") String status, @Bind("ordId") int ordId);
 /**
 * @param ordId to check status of order.
 * @return to return status details.
 */
  @SqlQuery("select * from ORDERS where ODR_ID = :ordId")
  @Mapper(OrdersMapper.class)
  Orders orderStatus(@Bind("ordId") int ordId);
  /**
   * @param cusId to get order coupon.
   * @return to return validation result.
   */

  @SqlQuery("select CUS_ID from ORDERS where CUS_ID = :cusId")
  @Mapper(OrdersMapper.class)
  int checkcoup(@Bind("cusId") int cusId);

   /**
    * @param itmId  add item id
    * @param cusId   add customer id
    * @param d1   add order date.
    * @return added orders
    */
  @SqlUpdate("insert into ORDERS(CUS_ID, ITM_ID, ORD_DATE) values(:cusId, :itmId, :ordDate)")
    int addOrderoff(@Bind("cusId") int cusId, @Bind("itmId") int itmId,
          @Bind("orddate") Date d1);

}

