package com.hexaware.MLP194.util;
import java.util.Scanner;
import com.hexaware.MLP194.factory.VendorFactory;
import com.hexaware.MLP194.factory.OrdersFactory;
import com.hexaware.MLP194.model.Orders;
import com.hexaware.MLP194.model.Vendor;
/**
 * To get Vendor.
 */
public class VendorUtil {
  private Scanner option = new Scanner(System.in, "UTF-8");
/**
 * To get Customer.
 */
  public final void detailsTableVendor() {
    try {
      System.out.println("change in Vendor details ? ");
      System.out.println("1. Sign Up");
      System.out.println("2. Login");
      System.out.println("3.add vendor details");
      System.out.println("4.display vendor details");
      System.out.println("5.update vendor details");
      System.out.println("6.vendor orders");
      System.out.println("7.Exit");
      final int tableOption = option.nextInt();
      switch (tableOption) {
        case 1:
          signUpVendor();
          break;
        case 2:
          loginVendor();
          break;
        case 3:
          addVendor();
          break;
        case 4:
          displayVendor();
          break;
        case 5:
          updateVendor();
          break;
        case 6:
          vendorOrders();
          break;
        case 7:
          Runtime.getRuntime().halt(0);
        default:
          System.out.println("Choose either 1 or 2 or 3 or 4");
      }
    } catch (final Exception e) {
      e.printStackTrace();
      System.out.println("enter a valid value");
    }
    option.nextLine();
    //mainMenu();
  }
  private void signUpVendor() {
    System.out.println("Enter your vendor details please");
    addVendor();
    System.out.println("Login into southern delights");
    loginVendor();
  }
  private void loginVendor() {
    System.out.println("Enter the vendor id");
    int vdrId = option.nextInt();
    System.out.println("Enter the Password");
    String pswd = option.next();
    Vendor c = VendorFactory.validatingVendor(vdrId, pswd);
    if (c.getVdrId() == vdrId && c.getPswd().equals(pswd)) {
      System.out.println("Welcome to Southern Delights");
    } else {
      System.out.println("Enter valid user id and password");
    }
  }
  private void displayVendor() {
    Vendor[] me = VendorFactory.showVendor();
    System.out.println("vdrId" + "\t" + "spl" + "\t" + "status");

    for (Vendor m : me) {
      System.out.println(m.getVdrId() + "\t" + m.getSpl() + "\t" + "\t" + m.getStatus());
    }
  }
  private void addVendor() {
    System.out.println("Enter Specialisation");
    final String spl = option.next();
    System.out.println("Enter status");
    final String status = option.next();
    System.out.println("Enter Vendor Id");
    final int vdrId = option.nextInt();
    System.out.println("Enter Password");
    final String pswd = option.next();
    System.out.println("Enter Phone number");
    final int phnNo = option.nextInt();
    final int i = VendorFactory.insertingVendor(spl, status, vdrId, pswd, phnNo);
    if (i > 0) {
      System.out.println("inserted successfully");
    } else {
      System.out.println("Not Inserted");
    }
  }
  private void updateVendor() {
    System.out.println("Enter specialisation");
    String spl = option.next();
    System.out.println("Enter Vendor Id");
    int vdrId = option.nextInt();
    int i = VendorFactory.updatingVendor(spl, vdrId);
    if (i >= 0) {
      System.out.println("updated successfully");
    } else {
      System.out.println("Not updated");
    }
  }
  private void vendorOrders() {
    System.out.println("Enter order Id");
    int ordId = option.nextInt();
    //String status = option.next();
    Orders m = OrdersFactory.orderingStatus(ordId);
    try {
      if (m.getStatus().equals("ORDERED")) {
        System.out.println("order accepted");
      }
    }  catch (Exception e) {
      System.out.println("order denied");
    }
  }
}

