package com.hexaware.MLP194.util;
//import java.text.ParseException;
//import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
//import javax.ws.rs.POST;
//import javax.ws.rs.PUT;
import javax.ws.rs.Path;
//import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.hexaware.MLP194.model.Orders;
import com.hexaware.MLP194.factory.OrdersFactory;

/**
 * This class provides a REST interface for the employee entity.
 */
@Path("/orders")
public class OrdersRest {
  /**
   * Returns Customer details.
   * @return the customer details
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public final Orders[] listOrders() {
    final Orders[] orders = OrdersFactory.showMenu();
    return orders;
  }

  /**
   * Returns order details.
   * @return the order details
   * @param newOrders orders are return.
   * @throws ParseException for exception.
   */
  /*@POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/insertingOrders")
  public final String insertOrders(final Orders newOrders) throws ParseException {
    /*String date1 = "2019-09-09";
    sdf = new SimpleDateFormat("yyyy-MM-dd");
    sdf.setLenient(false);
    d1 = sdf.parse(date1);
    final java.sql.Date sdate = new java.sql.Date(d1.getTime());
    String comment = "";
    final int ordIns = OrdersFactory.insertingOrders(123, "ORDERED", 1, 5100, 53, newOrders.getOrdDate(), 10001);
    if (ordIns > 0) {
      comment = "{\" value \" : \" Order added successfully \"}";
    } else {
      comment = "{\" value \" : \" Order not added  \"}";
    }
    return comment;
  }*/
  /**
   * Returns order details.
   * @return the order details
   * @param newOrders orders are return.
   */
  /*@PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/updateOrders")
  public final String updateOrders(final Orders newOrders) {
    String comment = "";
      //final int ordIns = OrdersFactory.updateOrders(newOrders);
    final int orderUpdate = OrdersFactory.updatingOrders("ORDERED", 21);
    if (orderUpdate > 0) {
      comment = "{\" value \" : \" Order updated successfully \"}";
    } else {
      comment = "{\" value \" : \" Order not updated  \"}";
    }

    return comment;

  }*/
  /**
   * Returns order details.
   * @return the order detail
   * @param ordId token parameter.
   */
  /*
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/showOrders/{ordId}")
  public final Orders showOrders(@PathParam("ordId") final int ordId) {
    final Orders newOrders = OrdersFactory.validatingOrderCoupon(21);
    return newOrders;
  }
  */
}
