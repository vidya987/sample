package com.hexaware.MLP194.factory;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import com.hexaware.MLP194.model.Coupon;
import com.hexaware.MLP194.persistence.DbConnection;
import com.hexaware.MLP194.persistence.CouponDAO;
/**
 * OffersFactory class used to fetch History data from database.
 */
public class CouponFactory {
  /**
   *  Protected constructor.
   */
  protected CouponFactory() {

  }
  /**
   * Call the data base connection.
   * @return the connection object.
   */
  private static CouponDAO dao() {
    DbConnection db = new DbConnection();
    return db.getConnect().onDemand(CouponDAO.class);
  }
  /**
   * Call the data base connection.
   * @return the array of offers object.
   */
  public static Coupon[] showOffers() {
    List<Coupon> offers = dao().show();
    return offers.toArray(new Coupon[offers.size()]);
  }
  /**
   *
   * @param cpnCode for coupon code.
   * @param dateend Coupon End.
   * @param datetoday Coupon today.
   * @param cusId Customer id.
   * @return to return coupon details.
   */
  public static int addCoupon(final String cpnCode, final LocalDate datetoday, final LocalDate dateend, final int cusId) {
    int i = dao().addCoupon(cpnCode, datetoday, dateend, cusId);
    return i;
  }
/**
 *
 * @param cusId for customer id.
 * @return to return customer id.
 */
  public static int checkcoupcus(final int cusId) {
    Coupon i = dao().checkcoupcus(cusId);
    int j = i.getCusId();
    return j;
  }
  /**
   * @param cid d
   * @return integer
   */
  //public static Date startcoupondate(final int cid) {
    //Offers u = dao().coupondate(cid);
    //Date i = u.getDateOfcoupon();
    //return i;
  //}

  /**
   * @param cusId for Customer id.
   * @return return values.
   */
  public static Date endcoupondate(final int cusId) {
    Coupon u = dao().coupondate(cusId);
    Date i = u.getcpnEndDate();
    return i;
  }
}


