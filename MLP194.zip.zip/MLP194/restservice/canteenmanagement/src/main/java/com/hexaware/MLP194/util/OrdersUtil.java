package com.hexaware.MLP194.util;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;
import com.hexaware.MLP194.factory.OrdersFactory;
import com.hexaware.MLP194.factory.VendorFactory;
import com.hexaware.MLP194.factory.CouponFactory;
import com.hexaware.MLP194.factory.CustomerFactory;
import com.hexaware.MLP194.factory.MenuFactory;

import com.hexaware.MLP194.model.Orders;
/**
 * To get Orders details.
 */
public class OrdersUtil {
  private final Scanner option = new Scanner(System.in, "UTF-8");
  private LocalDate datetoday = LocalDate.now();
  private Date d1;

  /**
   * To get Orders details.
   * @throws ParseException to handle exception.
   */
  public final void detailsTableOrders() throws ParseException {
    System.out.println("change in Order  ? ");
    System.out.println("1.add order details");
    System.out.println("2.display order details");
    System.out.println("3.update order details");
    System.out.println(".Exit");
    final int tableOption = option.nextInt();
    switch (tableOption) {
      case 1:
        insertOrders();
        break;
      case 2:
        displayOrders();
        break;
      case 3:
        updateOrders();
        break;
      case 4:
        Runtime.getRuntime().halt(0);
      default:
        System.out.println("Choose either 1 or 2 or 3 or 4");
    }
  }

  private void displayOrders() {
    final Orders[] me = OrdersFactory.showMenu();
    System.out.println("orderId" + "\t" + "\t" + "status" + "\t" + "Customer id" + "\t" + "vendor id" + "\t" + "tokenno"
        + "\t" + "\t" + "order Date");

    for (final Orders m : me) {
      System.out.println(m.getOrdId() + "\t" + "\t" + m.getStatus() + "\t" + "\t" + m.getCusId() + "\t" + m.getVdrId()
          + "\t" + "\t" + m.gettoken() + "\t" + "\t" + m.getOrdDate());
    }
  }
  private void insertOrders() throws ParseException {
    System.out.println("insert ordId" + "\t" + "status" + "\t" + "cusId" + "\t" + "vdrId"  + "\t" +  "orddate" +  "\t" + "itmid");
    int cpid = 0;
    System.out.println("Enter order id");
    final int ordId = option.nextInt();
    System.out.println("Enter status");
    final String status = option.next();
    System.out.println("Enter Customer id");
    final int cusId = option.nextInt();
    System.out.println("Enter vendor id");
    final int vdrId = option.nextInt();
    final int token = tokenGenerate();
    final Date ordDate = new Date();
    System.out.println("Enter Item Id");
    final int itmId = option.nextInt();
    //final int quantity = option.nextInt();
    //String od = ordDate.toString();
    final int i = OrdersFactory.insertingOrders(ordId, status, cusId, vdrId, token, ordDate, itmId);
    if (i > 0) {
      System.out.println("placed");
    } else {
      System.out.println("Not placed");
    }
   // d1 = new Date();
    try {
      cpid = OrdersFactory.validatingOrderCoupon(cusId);
    } catch (Exception e) {
      System.out.println("loading..");
    }
    if (cpid != cusId) {
      LocalDate dateend = datetoday.plusDays(15);
      System.out.println("\nCongrats !!! You have won a lucky coupon \nUse code: free10 \noffer valid till :" + dateend
          + "\n\n(Use within 15 days to redeem this offer)");
      String cpnCode = "free10";
      CouponFactory.addCoupon(cpnCode, datetoday, dateend, cusId);
    }
    System.out.println("Do u have any coupon??");
    String couchoi = option.next();
    if (couchoi.equals("y")) {
      System.out.println("Plz enter the code: ");
      String ipcode = option.next();
      if (ipcode.equals("free10")) {
        int cid = 0;
        try {
          System.out.println("loading wait..");
          cid = CouponFactory.checkcoupcus(cusId);
        } catch (Exception e) {
          System.out.println("loading..");
        }
        if (cid == cusId) {
          //Date endcoupondate = CouponFactory.endcoupondate(cusId);
          //String sendcoupon = endcoupondate.toString();
          String sdatetoday = datetoday.toString();
          //LocalDate locendcoupon = LocalDate.parse(sendcoupon);
          LocalDate locdatetoday = LocalDate.parse(sdatetoday);
          LocalDate locendcoupon = locdatetoday.plusDays(5);
          long validity = ChronoUnit.DAYS.between(locdatetoday, locendcoupon);
          if (validity <= 15) {
            int amoin = MenuFactory.validatingOrderCouponMenu(itmId);
            System.out.println("Enter quantity");
            final int quantity = option.nextInt();
            float amount  = amoin * quantity;
            System.out.println(amount);
            float discount = (amount * 10) / 100;
            float finalpricefloat = amount - discount;
            int finalprice = Math.round(finalpricefloat);
            System.out.println("\nOriginal Price: " + amount + "\nDiscounted amount: " + discount + "\nFinal Price: " + finalprice);
            OrdersFactory.addOrdersoff(cusId, itmId, d1);
            //CouponFactory.deleteCoupon(cusId);
            //Orders order = OrdersFactory.orderingStatus(cusId);
            //int me = MenuFactory.validatingOrderCouponMenu(itmId);
            if (quantity <= 5) {
              VendorFactory.updateVenStatus("\nPlaced");
              System.out.println("\nYour Order is Placed... :-)");
              if (amount > finalprice) {
                int balaNce = (int) (amount - finalprice);
                int check = CustomerFactory.deductAmount(cusId, balaNce);
                if (check > 0) {
                  System.out.println("Your order is placed.Deducted amount successfully......!");
                  int[] nums = new int[30];
                  Random randomGenerator = new Random();
                  for (int f = 0; f < nums.length; ++f) {
                    nums[f] = randomGenerator.nextInt(30);
                  }
                }
              }
            }
          }
          if (validity > 16) {
            System.out.println("\nOffer Period is EXPIRED!!");
          } else {
            System.out.println("offfer accepted");
          }
        }
      }
    }
  }
  private void updateOrders() {
    System.out.println("Enter status");
    final String status = option.next();
    System.out.println("Enter order Id");
    final int ordId = option.nextInt();
    final int i = OrdersFactory.updatingOrders(status, ordId);
    if (i >= 0) {
      System.out.println("updated successfully");
    } else {
      System.out.println("Not updated");
    }
  }
  private int tokenGenerate() {
    final int orders = (int) OrdersFactory.createToken();
    return orders;
  }
}

