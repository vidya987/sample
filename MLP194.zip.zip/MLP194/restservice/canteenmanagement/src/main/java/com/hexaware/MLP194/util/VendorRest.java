package com.hexaware.MLP194.util;
//import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
//import javax.ws.rs.POST;
//import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
//import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import com.hexaware.MLP194.model.Vendor;
import com.hexaware.MLP194.factory.VendorFactory;

/**
 * This class provides a REST interface for the employee entity.
 */
@Path("/vendor")
public class VendorRest {
  /**
   * Returns vendor details.
   * @return the vendor details
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public final Vendor[] listVendor() {
    final Vendor[] vendor = VendorFactory.showVendor();
    return vendor;
  }

  /**
   * Returns vendor details.
   * @return the vendor details
   * @param newVendor gets vendor.
   */
  /*@POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/insertvendor")
  public final String insertVendor(final Vendor newVendor) {
    String comment = "";
    //final int venIns = VendorFactory.insertingVendor(newVendor);
    final int venInsert = VendorFactory.insertingVendor(newVendor.getVdrId(), newVendor.get);
    if (venInsert > 0) {
      comment = "{\" value \" : \" Vendor updated successfully \"}";
    } else {
      comment = "{\" value \" : \" Vendor not updated  \"}";
    }
    return comment;
  }*/
  /**
   * Returns vendor details.
   * @return the vendor details
   *  @param newVendor gets vendor.
   */
  /*@PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/updateVendor")
  public final String updateVendor(final Vendor newVendor) {
    String comment = "";
      //final int venUpd = VendorFactory.updateVendor(newVendor);
    final int venUpdate = VendorFactory.updatingVendor(newVendor);
    if (venUpdate > 0) {
      comment = "{\" value \" : \" Vendor updated successfully \"}";
    } else {
      comment = "{\" value \" : \" Vendor not updated  \"}";
    }

    return comment;

  }*/
  /**
   * Show wallet balance of vendor.
   * @return the wallet balance of vendor.
   * @param vdrId for vendor Id.
   * @param pswd for vendor Id.
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/vendorwallet/{vdrId}")
  public final Vendor showVenWallet(@PathParam("vdrId") final int vdrId, @PathParam("pswd") final String pswd) {
    Vendor walletV = VendorFactory.validatingVendor(vdrId, pswd);
    return walletV;
  }
}
