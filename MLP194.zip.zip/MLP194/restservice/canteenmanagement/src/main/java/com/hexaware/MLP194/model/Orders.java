package com.hexaware.MLP194.model;
import java.util.Date;
/**
 * Order class used to display wallet information.
 * @author hexware
 */
public class Orders {
  private int ordId;
  private String status;
  private int cusId;
  private int vdrId;
  private int token;
  private Date ordDate;
  private int itmId;
/**
 * to display orders.
 */
  @Override
  public final int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + cusId;
    //result = prime * result + ((ordDate == null) ? 0 : ordDate.hashCode());
    result = prime * result + ordId;
    //result = prime * result + ((status == null) ? 0 : status.hashCode());
    result = prime * result + token;
    result = prime * result + vdrId;
    result = prime * result + itmId;
    return result;
  }
/**
 * to display orders.
 */
  @Override
  public final boolean equals(final Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final Orders other = (Orders) obj;
    if (cusId != other.cusId) {
      return false;
    }
    if (ordDate == null) {
      if (other.ordDate != null) {
        return false;
      }
    } else if (!ordDate.equals(other.ordDate)) {
      return false;
    }
    if (ordId != other.ordId) {
      return false;
    }
    if (status == null) {
      if (other.status != null) {
        return false;
      }
    } else if (!status.equals(other.status)) {
      return false;
    }
    if (token != other.token) {
      return false;
    }
    if (vdrId != other.vdrId) {
      return false;
    }
    if (itmId != other.itmId) {
      return false;
    }
    return true;
  }

/**
 * @param argordId to initialise order id
 * @param argstatus to  initialise order status
 * @param argcusId to initialise customer id
 * @param argvdrId to  initialise vendor id
 * @param argtoken to initialise token
 * @param orddate to initialise Date.
 * @param argitmId to initialise item id.
 */

  public Orders(final int argordId, final String argstatus, final int argcusId, final int argvdrId,
      final int argtoken, final int argitmId, final Date orddate) {
    this.ordId = argordId;
    this.status = argstatus;
    this.cusId = argcusId;
    this.vdrId = argvdrId;
    this.token = argtoken;
    this.ordDate = new Date(orddate.getTime());
    this.itmId = argitmId;
  }
/**
 * @return to get the customer id.
 */
  public final int getCusId() {
    return cusId;
  }
/**
 * @param argcusId to set the customer id
 */
  public final void setCusId(final int argcusId) {
    this.cusId = argcusId;
  }
/**
 * @return to get the vendor id
 */
  public final int getVdrId() {
    return vdrId;
  }
/**
 * @param argvdrId to set the vendor id.
 */
  public final void setVdrId(final int argvdrId) {
    this.vdrId = argvdrId;
  }
/**
 * @return to get the order history.
 */
  public final int gettoken() {
    return token;
  }
/**
 * @param argtoken to set the order history
 */
  public final void settoken(final int argtoken) {
    this.token = argtoken;
  }
  /**
   * @return to get Date.
   */
  public final Date getOrdDate() {
    return new Date(ordDate.getTime());
    //return ordDate;
  }
  /**
   * @param d1 to set Date.
   */

  public final void setOrdDate(final Date d1) {
    this.ordDate = new Date(ordDate.getTime());
  }
/**
 * @return to return order id.
 */
  public final int getOrdId() {
    return ordId;
  }
/**
 * @param argordId to set order id.
 */
  public final void setOrdId(final int argordId) {
    this.ordId = argordId;
  }
/**
 * @return to return Status.
 */
  public final String getStatus() {
    return status;
  }
/**
 * @param argstatus to set order id.
 */
  public final void setStatus(final String argstatus) {
    this.status = argstatus;
  }
  /**
 * @return to return Token.
 */
  public final int getItemId() {
    return itmId;
  }
/**
* @param argitmId to set Token.
*/
  public final void setItemId(final int argitmId) {
    this.itmId = argitmId;
  }
/**
 * Default Constructor .
 */
  public Orders() {
  }
}
