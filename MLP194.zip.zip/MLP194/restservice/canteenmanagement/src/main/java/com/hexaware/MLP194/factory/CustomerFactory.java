package com.hexaware.MLP194.factory;
import com.hexaware.MLP194.persistence.CustomerDAO;
import com.hexaware.MLP194.persistence.DbConnection;
import java.util.List;
import com.hexaware.MLP194.model.Customer;
/**
 * MenuFactory class used to fetch menu data from database.
 * @author hexware
 */
public class CustomerFactory {
  /**
   *  Protected constructor.
   */
  protected CustomerFactory() {

  }
  /**
   * Call the data base connection.
   * @return the connection object.
   */
  private static CustomerDAO dao() {
    DbConnection db = new DbConnection();
    return db.getConnect().onDemand(CustomerDAO.class);
  }
  /**
   * Call the data base connection.
   * @return the array of customer object.
   */
  public static Customer[] showCustomer() {
    List<Customer> m = dao().show();
    return m.toArray(new Customer[m.size()]);
  }

    /**
     * @param cusId to insert customer name.
     * @param walNo to insert wallet number.
     * @param phnNo to insert customer phone number.
     * @param addRess to insert customer address.
     * @param crdNo to insert customer card number.
     * @param pswd to insert password.
     *  @param balance to insert balance.
     * @return to return inserted value.
     */

  public static int insertingCustomer(final int cusId, final int walNo, final long phnNo, final String addRess,
      final int crdNo, final String pswd, final int balance) {
    int i = dao().insert(cusId, walNo, phnNo, addRess, crdNo, pswd, balance);
    return i;
  }
  /**
   * @param phnNo to update phone number.
   * @param cusId to update customer id.
   * @param addRess to update address.
   * @return to return updated value.
   */
  public static int updatingCustomer(final long phnNo, final String addRess, final int cusId) {
    int check = dao().update(phnNo, addRess, cusId);
    return check;
  }
  /**
   * @param cusId to validate customer id.
   * @param pswd to valiidate passwword.
   * @return to return validation result.
   */

  public static Customer validatingCustomer(final int cusId, final String pswd) {
    Customer customer = dao().validating(cusId, pswd);
    return customer;
  }

  /**
   * @param cusId to validate customer id.
   * @return
   * @return to return validation result.
   */
  public static Customer validatingCustomerCoupon(final int cusId) {
    Customer customer = dao().customerCoupon(cusId);
    return customer;
  }
  /**
   * @param newCustomer to validate customer id.
   * @return
   * @return to return validation result.
   */
  /*
  public static int insertingCustomer(final Customer newCustomer) {
    int i = dao().insert(newCustomer.getCusId(), newCustomer.getWalNo(), newCustomer.getPhnNo(),
        newCustomer.getAddRess(), newCustomer.getCrdNo(), newCustomer.getPswd(), newCustomer.getbalance());
    return i;
  }
  */
/**
   * @param newCustomer to validate customer id.
   * @return
   * @return to return validation result.
   */
  /*
  public static int updatingCustomer(final Customer newCustomer) {
    int check = dao().update(newCustomer.getPhnNo(), newCustomer.getAddRess(), newCustomer.getCusId());
    return check;
  }
  */
  /**
   * @param cusId customer id.
   * @param balaNce to detect balance.
   * @return return
   */
  public static int deductAmount(final int balaNce, final int cusId) {
    int i = dao().updateWallet(balaNce, cusId);
    return i;
  }
}



