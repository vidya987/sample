package com.hexaware.MLP194.factory;
import com.hexaware.MLP194.persistence.VendorDAO;
import com.hexaware.MLP194.persistence.DbConnection;
import java.util.List;
import com.hexaware.MLP194.model.Vendor;
/**
 * MenuFactory class used to fetch menu data from database.
 * @author hexware
 */
public class VendorFactory {
  /**
   *  Protected constructor.
   */
  protected VendorFactory() {
  }
  /**
   * Call the data base connection.
   * @return the connection object.
   */
  private static VendorDAO dao() {
    final DbConnection db = new DbConnection();
    return db.getConnect().onDemand(VendorDAO.class);
  }

  /**
   * Call the data base connection.
   * @return the array of vendor object.
   */
  public static Vendor[] showVendor() {
    final List<Vendor> k = dao().show();
    return k.toArray(new Vendor[k.size()]);
  }

  /**
   * @param spl to insert specialisation.
   * @param status to insert status.
   * @param vdrId to insert vendor Id.
   * @param pswd to insert password
   * @param phnNo to insert phone number
   * @return to return inserted values.
   */
  public static int insertingVendor(final String spl, final String status, final int vdrId, final String pswd, final long phnNo) {
    final int i = dao().insertVendor(spl, status, vdrId, pswd,  phnNo);
    return i;
  }
  /**
   * @param spl to insert specialisation.
   * @param vdrId to insert status.
   * @return to return updated values.
   */
  public static int updatingVendor(final String spl, final int vdrId) {
    int i = dao().updateVendor(spl, vdrId);
    return i;
  }
/**
   * @param vdrId To list out Vendor id.
   * @param pswd to validate password.
   * @return to return vendor details.
   */
  public static Vendor validatingVendor(final int vdrId, final String pswd) {
    final Vendor vendors = dao().validatingVendors(vdrId, pswd);
    return vendors;
  }
   /**
   * @param newVendor to insert specialisation.
   * @return to return inserted values.
   */
  /*public static int insertingVendor(final Vendor newVendor) {
    final int i = dao().insertVendor(newVendor.getSpl(), newVendor.getStatus(), newVendor.getVdrId(), newVendor.getPswd(), newVendor.getPhnNo());
    return i;
  }
  */
   /**
   * @param newVendor to insert specialisation.
   * @return to return inserted values.
   */
  /*
  public static int updatingVendor(final Vendor newVendor) {
    int i = dao().updateVendor(newVendor.getStatus(), newVendor.getVdrId());
    return i;
  }*/
   /**
   * @param status to update status.
   * @return integer
   */
  public static int updateVenStatus(final String status) {
    int k = dao().updateStatus(status);
    return k;
  }
}
