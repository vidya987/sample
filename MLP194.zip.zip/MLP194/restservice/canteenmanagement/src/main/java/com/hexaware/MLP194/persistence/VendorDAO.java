package com.hexaware.MLP194.persistence;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import java.util.List;
import com.hexaware.MLP194.model.Vendor;
/**
 * VendorDAO class used to fetch data from data base.
 * @author hexware
 */
public interface VendorDAO {
    /**
     * @return the all the Vendor record.
     */
  @SqlQuery("Select * from Vendor")
    @Mapper(VendorMapper.class)
    List<Vendor> show();
    /**
     * @param spl for specialisation.
     * @param status for status.
     * @param vdrId for vendor status.
     * @param phnNo for phone number.
     * @param pswd for password.
     * @return for vendor required details.
     */
  @SqlUpdate("insert into Vendor(SPL,STATUS,VDR_ID, PSWD, PHN_NO)" + " VALUES (:spl,:status,:vdrId, :pswd, :phnNo,)")
    int insertVendor(@Bind("spl") String spl, @Bind("status") String status, @Bind("vdrId") int vdrId,
      @Bind("pswd") String pswd, @Bind("phnNo") long phnNo);
    /**
     * @param status for specialisation.
     * @param vdrId for vendor id.
     * @return to return vendor updated details.
     */

  @SqlUpdate("Update Vendor set STATUS = :status where VDR_ID = :vdrId")
    int updateVendor(@Bind("status") String status, @Bind("vdrId") int vdrId);

 /**
 * @param vdrId to check vendor id.
 * @param pswd to check password.
 * @return to return validation result.
 */

  @SqlQuery("select * from Customer where VDR_ID = :cusId and PSWD = :pswd")
  @Mapper(VendorMapper.class)
  Vendor validatingVendors(@Bind("vdrId") int vdrId, @Bind("pswd") String pswd);

  /**
  * @param status getting status
  * @return to return status.
  */
  @SqlUpdate("update VENDORS set STATUS = :status")
  int updateStatus(@Bind("status") String status);
}
