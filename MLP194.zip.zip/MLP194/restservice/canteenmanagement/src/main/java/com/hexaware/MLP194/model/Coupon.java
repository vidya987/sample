package com.hexaware.MLP194.model;
//import java.time.LocalDate;
import java.util.Date;
/**
 * Coupon class used to display menu information.
 */
public class Coupon {
  /**
   * cpnCode for cpn code.
   * cpnDate for cpn date.
   * cpnEndDate for cpn end date.
   * cusId for customer id.
   */

  private String cpnCode;
  private Date cpnDate;
  private Date cpnEndDate;
  private int cusId;

/**
 * Default Constructor.
 */
  public Coupon() {
  }

    /**
     * @param argcpnCode for coupon code.
     * @param argcpnDate for coupon date.
     * @param argcpnEndDate for coupon end date.
     * @param argcusId for customer id.
     */
  public Coupon(final String argcpnCode, final Date argcpnDate, final Date argcpnEndDate,
      final int argcusId) {
    this.cpnCode = argcpnCode;
    this.cpnDate = new Date(argcpnDate.getTime());
    this.cusId = argcusId;
    this.cpnEndDate = new Date(argcpnEndDate.getTime());
  }

    /**
     * @return the coupon_code
     */
  public final String getCpnCode() {
    return cpnCode;
  }

    /**
     * @param argCpnCode the coupon_code to set
     */
  public final void setCpnCode(final String argCpnCode) {
    this.cpnCode = argCpnCode;
  }

    /**
     * @return the dateOfcoupon
     */
  public final Date getcpnDate() {
    return new Date(cpnDate.getTime());
  }
    /**
     * @param argcpnDate the dateOfcoupon to set
     */
  public final void setcpnDate(final Date argcpnDate) {
    this.cpnDate = new Date(argcpnDate.getTime());
  }

    /**
     * @return the cus_id
     */
  public final int getCusId() {
    return cusId;
  }

    /**
     * @param argcusId the cus_id to set
     */
  public final void setCusId(final int argcusId) {
    this.cusId = argcusId;
  }

  /**
     * @return the dateOfcouponend
     */
  public final Date getcpnEndDate() {
    return new Date(cpnEndDate.getTime());
  }
      /**
       * @param argcpnEndDate the dateOfcoupon to set
       */
  public final void setcpnEndDate(final Date argcpnEndDate) {
    this.cpnEndDate = new Date(argcpnEndDate.getTime());
  }

  @Override
    public final int hashCode() {
    final int prime = 31;
    int result = 1;
    //result = prime * result + ((coupon_code == null) ? 0 : coupon_code.hashCode());
    result = prime * result + cusId;
    //result = prime * result + ((dateOfcoupon == null) ? 0 : dateOfcoupon.hashCode());
    return result;
  }

  @Override
    public final boolean equals(final Object obj) {
    if (this == obj) {
      return true;
    }
    if (!(obj instanceof Coupon)) {
      return false;
    }
    Coupon other = (Coupon) obj;
    if (cpnCode == null) {
      if (other.cpnCode != null) {
        return false;
      }
    } else if (!cpnCode.equals(other.cpnCode)) {
      return false;
    }
    if (cusId != other.cusId) {
      return false;
    }
    if (cpnDate == null) {
      if (other.cpnDate != null) {
        return false;
      }
    } else if (!cpnDate.equals(other.cpnDate)) {
      return false;
    }
    if (cpnEndDate == null) {
      if (other.cpnEndDate != null) {
        return false;
      }
    } else if (!cpnEndDate.equals(other.cpnEndDate)) {
      return false;
    }
    return true;
  }
  /**
   * to convert to String.
   */

  @Override
  public final String toString() {
    return "Coupon [cpnCode=" + cpnCode + ", cpnDate=" + cpnDate + ", cpnEndDate=" + cpnEndDate + ", cusId=" + cusId
        + "]";
  }
}
