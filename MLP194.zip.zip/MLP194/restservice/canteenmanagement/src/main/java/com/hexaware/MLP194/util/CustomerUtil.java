package com.hexaware.MLP194.util;
import java.util.Scanner;
import com.hexaware.MLP194.factory.CustomerFactory;
import com.hexaware.MLP194.model.Customer;
/**
 * To get Customer.
 */
public class CustomerUtil {
  private Scanner option = new Scanner(System.in, "UTF-8");
/**
 * To get Customer.
 */
  public final void detailsTableCustomer() {
    try {
      System.out.println("change in Customer details? ");
      System.out.println("1. Sign Up");
      System.out.println("2. Login");
      System.out.println("3. add into Customer");
      System.out.println("4. display customer");
      System.out.println("5. Update customer");
      System.out.println("6. Exit");
      final int tableOption = option.nextInt();
      switch (tableOption) {
        case 1:
          signUp();
          break;
        case 2:
          loginCustomer();
          break;
        case 3:
          addCustomers();
          break;
        case 4:
          showCustomer();
          break;
        case 5:
          editCustomer();
          break;
        case 6:
          Runtime.getRuntime().halt(0);
        default:
          System.out.println("Choose either 1 or 2 or 3 or 4");
      }
    } catch (final Exception e) {
      e.printStackTrace();
      System.out.println("enter a valid value");
    }
    option.nextLine();
  }
  private void signUp() {
    System.out.println("Enter your customer details please");
    addCustomers();
    System.out.println("Login into southern delights");
    loginCustomer();
  }
  private void loginCustomer() {
    System.out.println("Enter the Customer id");
    int cusId = option.nextInt();
    System.out.println("Enter the Password");
    String pswd = option.next();
    Customer c = CustomerFactory.validatingCustomer(cusId, pswd);
    if (c.getCusId() == cusId && c.getPswd().equals(pswd)) {
      System.out.println("Welcome to Southern Delights");
    } else {
      System.out.println("Enter valid user id and password");
    }
  }
  private void addCustomers() {
    System.out.println("Enter the passowrd between 8 to 13 characters");
    System.out.println("Customer Id");
    int cusId = option.nextInt();
    System.out.println("Wallet number");
    int walNo = option.nextInt();
    System.out.println("Phone Number");
    long phnNo = option.nextLong();
    System.out.println("Address");
    String addRess = option.next();
    System.out.println("Card number");
    int crdNo = option.nextInt();
    System.out.println("Password");
    String pswd = option.next();
    System.out.println("Balance");
    int balance = option.nextInt();
    try {
      if (pswd.length() >= 8 && pswd.length() <= 13) {
        System.out.println("Password accepted");
      }
    } catch (Exception e) {
      System.out.println("Enter correct password.");
    }
    int i = CustomerFactory.insertingCustomer(cusId, walNo, phnNo, addRess, crdNo, pswd, balance);
    if (i > 0) {
      System.out.println("inserted successfully");
    } else {
      System.out.println("Not Inserted");
    }
  }
  private void editCustomer() {
    System.out.println("Enter phone number");
    long phnNo = option.nextLong();
    System.out.println("Enter Address");
    String addRess = option.next();
    System.out.println("Enter Customer id");
    int cusId = option.nextInt();
    int check = CustomerFactory.updatingCustomer(phnNo, addRess, cusId);
    if (check > 0) {
      System.out.println("updated successfully");
    } else {
      System.out.println("Sorry ! not updated");
    }
  }
  private void showCustomer() {
    Customer[] me = CustomerFactory.showCustomer();
    System.out.println("id" + "\t" + "wallet number" + "\t" + "\t" + "phone number" + "\t" + "\t"
         + "Address" + "\t" + "\t" + "\t" + "card number" + "\t" + "\t" + "password" + "\t" + "balance");
    for (Customer m : me) {
      System.out.println(m.getCusId() + "\t" + m.getWalNo() + "\t" + "\t" + m.getPhnNo() + "\t" + "\t"
          + m.getAddRess() + "\t" + "\t" + "\t" + m.getCrdNo() +  "\t" + "\t" + m.getPswd() + "\t" + "\t" + m.getbalance());
    }
  }

}
