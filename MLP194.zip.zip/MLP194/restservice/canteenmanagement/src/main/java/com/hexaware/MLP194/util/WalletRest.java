package com.hexaware.MLP194.util;
//import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
//import javax.ws.rs.POST;
//import javax.ws.rs.PUT;
import javax.ws.rs.Path;
//import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.hexaware.MLP194.model.Wallet;
import com.hexaware.MLP194.factory.WalletFactory;
/**
 * This class provides a REST interface for the employee entity.
 */
@Path("/Wallet")
public class WalletRest {
  /**
   * Returns Customer details.
   * @return the Customer details
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/listWallet")
  public final Wallet[] listWallet() {
    final Wallet[] c = WalletFactory.showMenu();
    return c;
  }
}
/**
 * @param newWallet to post Customer .
 * @return to post to databse.
 */
  /*@POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/insertWallet")
public final String insertWallet(final Wallet newWallet) {
    String comment = "";
    final int walletIns = WalletFactory.insertingWallet(newWallet.getwltPt(), newWallet.getwltNo(), newWallet.getCusId(), newWallet.getbalance());
    if (walletIns > 0) {
      comment = "{\" value \" : \" Wallet added successfully \"}";
    } else {
      comment = "{\" value \" : \" Wallet not added  \"}";
    }
    return comment;
  }
/**
* @param newWallet to modify Customer .
* @return to return values.
*/
  /*@PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/updateWallet")
public final String updateWallet(final Wallet newWallet) {
    String comment = "";
    final int walletUpdate = WalletFactory.updatingWallet(newWallet.getwltPt(), newWallet.getwltNo());
    if (walletUpdate > 0) {
      comment = "{\" value \" : \" Wallet updated successfully \"}";
    } else {
      comment = "{\" value \" : \" Wallet not updated  \"}";
    }
    return comment;
  }

/**
* @param cusId to get wallet point.
* @return to return the values.
*/
  /*@GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/showWallet/{cusId}")
public final int balanceWallet(@PathParam("cusId") final Wallet cusId) {
    final int w = WalletFactory.balancingAmount(cusId.getbalance(), cusId.getCusId());
    return w;
  }
}*/



