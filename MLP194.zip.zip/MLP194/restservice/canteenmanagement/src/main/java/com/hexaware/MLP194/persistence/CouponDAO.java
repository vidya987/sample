package com.hexaware.MLP194.persistence;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import java.time.LocalDate;
import java.util.List;
import com.hexaware.MLP194.model.Coupon;
/**
 * HistoryDAO class used to obtain History from data base.
 */
public interface CouponDAO {
    /**
     * @return the all the offers record.
     */
  @SqlQuery("Select * from COUPON")
    @Mapper(CouponMapper.class)
    List<Coupon> show();

/**
 *
 * @param cpnCode coupon code.
 * @param cpnDate coupon Date.
 * @param cpnEndDate coupon end Date.
 * @param cusId customer id.
 * @return addingoffers
 */
  @SqlUpdate("INSERT INTO COUPON (CPN_CODE , CPN_DATE,CPNED_DATE, CUS_ID) VALUES(:cpnCode , :cpnDate, :cpnEndDate, :cusId)")
    int addCoupon(@Bind("cpnCode") String cpnCode, @Bind("cpnDate") LocalDate cpnDate,
      @Bind("cpnEndDate") LocalDate cpnEndDate, @Bind("cusId") int cusId);
/**
 *
 * @param cusId customer id.
 * @return to return customer id.
 */
  @SqlUpdate("DELETE FROM COUPON WHERE CUS_ID = (:cusId)")
 int deleteCoupon(@Bind("cusId") int cusId);
/**
 *
 * @param cusId customer id.
 * @return  to return customer id.
 */
  @SqlQuery("select * from COUPON where CUS_ID = :cusId")
    @Mapper(CouponMapper.class)
     Coupon checkcoupcus(@Bind("cusId") int cusId);
/**
 *
 * @param cusId customer id.
 * @return to return customer id.
 */
  @SqlQuery("Select * from COUPON where CUS_ID = :cusId")
    @Mapper(CouponMapper.class)
      Coupon coupondate(@Bind("cusId") int cusId);

}
