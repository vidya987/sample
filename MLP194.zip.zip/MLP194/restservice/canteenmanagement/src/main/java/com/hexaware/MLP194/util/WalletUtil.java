package com.hexaware.MLP194.util;
import java.util.Scanner;
import com.hexaware.MLP194.factory.WalletFactory;
import com.hexaware.MLP194.model.Wallet;
/**
 * To getWallet.
 */
public class WalletUtil {
  private Scanner option = new Scanner(System.in, "UTF-8");
/**
 * To get Wallet.
 */
  public final void detailsTableWallet() {
    try {
      System.out.println("change in Wallet details ? ");
      System.out.println("1.add wallet details");
      System.out.println("2.display wallet details");
      System.out.println("3.update wallet details");
      System.out.println("4. wallet details");
      System.out.println("5. Exit");
      final int tableOption = option.nextInt();
      switch (tableOption) {
        case 1:
          addCustomerWallet();
          break;
        case 2:
          displayWallet();
          break;
        case 3:
          updateWallet();
          break;
        case 4:
          walletAmount();
          break;
        case 5:
          Runtime.getRuntime().halt(0);
        default:
          System.out.println("Choose either 1 or 2 or 3 or 4");
      }
    } catch (final Exception e) {
      e.printStackTrace();
      System.out.println("enter a valid value");
    }
    option.nextLine();
    //mainMenu();
  }
  private void addCustomerWallet() {
    System.out.println("Enter Wallet point");
    int walPt = option.nextInt();
    System.out.println("Enter Wallet number");
    int walNo = option.nextInt();
    System.out.println("Enter Customer Id");
    int cusId = option.nextInt();
    System.out.println("Enter Amount");
    int amouNt = option.nextInt();
    int i = WalletFactory.insertingWallet(walPt, walNo, cusId, amouNt);
    if (i > 0) {
      System.out.println("inserted successfully");
    } else {
      System.out.println("Not Inserted");
    }
  }
  private void displayWallet() {
    Wallet[] me = WalletFactory.showMenu();
    System.out.println("point" + "\t" + "wallet number" + "\t" + "Customer id" + "\t" + "balance");

    for (Wallet m : me) {
      System.out.println(m.getwltPt() + "\t" + m.getwltNo() + "\t" + "\t" + m.getCusId() + "\t" + m.getbalance());
    }
  }
  private void updateWallet() {
    System.out.println("Enter Wallet point");
    int walPt = option.nextInt();
    System.out.println("Enter Wallet number");
    int walNo = option.nextInt();
    int i = WalletFactory.updatingWallet(walPt, walNo);
    if (i >= 0) {
      System.out.println("updated successfully");
    } else {
      System.out.println("Not updated");
    }
  }
  private void walletAmount() {
    System.out.println("Enter Customer Id");
    int cusId = option.nextInt();
    System.out.println("Enter Amount");
    int amouNt = option.nextInt();
    System.out.println("Enter Total");
    int total = option.nextInt();
    int bal = amouNt - total;
    int i = WalletFactory.balancingAmount(bal, cusId);
    //int bal = amouNt - total;
    if (i > 0) {
      System.out.println(bal);
    } else {
      System.out.println("Not placed");
    }
  }
}
