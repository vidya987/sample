package com.hexaware.MLP194.util;
//import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
//import javax.ws.rs.POST;
//import javax.ws.rs.PUT;
import javax.ws.rs.Path;
//import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.hexaware.MLP194.model.Customer;
import com.hexaware.MLP194.factory.CustomerFactory;
/**
 * This class provides a REST interface for the employee entity.
 */
@Path("/Customer")
public class CustomerRest {
  /**
   * Returns Customer details.
   * @return the Customer details
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/listcustomer")
  public final Customer[] listMenu() {
    final Customer[] c = CustomerFactory.showCustomer();
    return c;
  }
}
    /**
   * Returns vendor details.
   * @return the vendor details
   * @param newCustomer gets vendor.
   */
  /*@POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/insertCustomer")
  public final String insertVendor(final Customer newCustomer) {
    String comment = "";
    //final int venIns = VendorFactory.insertingVendor(newVendor);
    final int venInsert = CustomerFactory.insertingCustomer(1, 1221, 9600340997L, "karapakkam", 103, "thankgod2", 15000);
    if (venInsert > 0) {
      comment = "{\" value \" : \" Vendor updated successfully \"}";
    } else {
      comment = "{\" value \" : \" Vendor not updated  \"}";
    }
    return comment;
  }
  /**
   * Returns vendor details.
   * @return the vendor details
   *  @param newCustomer gets vendor.
   */
  /*@PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/updateCustomer")
  public final String updateCustomer(final Customer newCustomer) {
    String comment = "";
      //final int venUpd = VendorFactory.updateVendor(newVendor);
    final int venUpdate = CustomerFactory.updatingCustomer(9600340997L, "karapakkam", 1);
    if (venUpdate > 0) {
      comment = "{\" value \" : \" Vendor updated successfully \"}";
    } else {
      comment = "{\" value \" : \" Vendor not updated  \"}";
    }

    return comment;

  }
  /**
   * Show wallet balance of vendor.
   * @return the wallet balance of vendor.
   * @param cusId for vendor Id.
   * @param pswd for vendor Id.
   */
  /*@GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/customer/{cusId}")
  public final Customer showVenWallet(@PathParam("cusId") final int cusId, @PathParam("pswd") final String pswd) {
    Customer walletV = CustomerFactory.validatingCustomer(cusId, pswd);
    return walletV;
  }
}*/

