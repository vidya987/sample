package com.hexaware.MLP194.persistence;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import java.util.List;
import com.hexaware.MLP194.model.Menu;
/**
 * MenuDAO class used to fetch data from data base.
 * @author hexware
 */
public interface MenuDAO {
    /**
     * @return the all the Menu record.
     */
  @SqlQuery("Select * from Menu")
    @Mapper(MenuMapper.class)
    List<Menu> show();
  /**
     * @return the all the Menu record.
     * @param itmId to update item id.
     * @param price to update item id.
     */
  @SqlUpdate("Update MENU set PRICE=(:price) where ITM_ID =(:itmId)")
    int updateAmount(@Bind("price") int price, @Bind("itmId") int itmId);
    /**
     * @param itmId to get customer coupon.
     * @return to return validation result.
*/
  @SqlQuery("select * from MENU where ITM_ID = :itmId ")
  @Mapper(MenuMapper.class)
  Menu customerCoupon(@Bind("itmId") int itmId);
}
