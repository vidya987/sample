package com.hexaware.MLP194.integration.test;
import java.net.URI;
import java.net.URISyntaxException;
/**
 *@author hexaware
 */

class CommonUtil {
  /**
   * @param HOSTID to get host id.
   */

  public static final String HOSTID;
  /**
   * @param PORTID to get host id.
   */
  public static final String PORTID;
  /**
   *  @param WEBAPP to get host id.
   */
  public static final String WEBAPP;
  /**
   * @param URIPREFIX to get host id.
   */
  public static final String URIPREFIX;

  static {
    HOSTID = System.getProperty("service.host", "localhost");
    PORTID = System.getProperty("service.port", "8080");
    WEBAPP = System.getProperty("service.webapp", "MLP194");
    URIPREFIX = "http://" + HOSTID + ":" + PORTID + "/" + WEBAPP;
  }
  /**
   * @param path to get path
   * @return path
   * @throws URISyntaxException for Exception handling.
   */
  public static URI getURI(final String path) throws URISyntaxException {
    return new URI(URIPREFIX + path);
  }
}

