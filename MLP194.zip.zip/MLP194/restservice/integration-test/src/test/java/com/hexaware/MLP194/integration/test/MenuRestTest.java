package com.hexaware.MLP194.integration.test;
import java.net.URISyntaxException;
import org.junit.Test;
import com.jayway.restassured.http.ContentType;
import static com.jayway.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

/**
 * to declare a class MenuRestTest.
 */
public class MenuRestTest {
/**
* @throws AssertionError to throw error.
* @throws URISyntaxException to handle exception.
*/

  @Test
public void testMenuList() throws AssertionError, URISyntaxException {
    Menu[] res = given().when().accept(ContentType.JSON).get(CommonUtil.getURI("/api/menu")).getBody().as(Menu[].class);
    assertEquals(5, res.length);
    assertEquals(10001, res[0].getItmId());
    assertEquals("Dosa", res[0].getItmName());
    assertEquals(45, res[0].getPrice(), 0.1);
    assertEquals("Plain Dosa", res[0].getPriDes());
    assertEquals(2, res[0].getQty());
  }
  /**
   * @throws AssertionError to throw error.
   * @throws URISyntaxException to handle exception.
   */
  @Test
public void testFoodDetails() throws AssertionError, URISyntaxException {
    Menu m = given().accept(ContentType.JSON).when().get(CommonUtil.getURI("/api/menu/FoodDetails/101")).getBody().as(Menu.class);
    assertEquals(101, m.getItmId());
    assertEquals("Dosa", m.getItmName());
    assertEquals(80, m.getPrice(), 0.1);
    assertEquals("Plain Dosa", m.getPriDes(), 0.1);
    assertEquals(2, m.getQty());
  }
 /**
* @throws AssertionError to throw error.
* @throws URISyntaxException to handle exception.
*/
  @Test
public void testMenuById404() throws AssertionError, URISyntaxException {
    given().accept(ContentType.JSON).when().get(CommonUtil.getURI("/api/menu/1010")).then().assertThat().statusCode(404);
  }
}
